import { MobileBottomNav } from "@/components/navigation/MobileBottomNav";
import { Header } from "@/sections/Header";
import { Main } from "@/sections/Main";
import { Footer } from "@/sections/Footer";
import { MobileMenu } from "@/components/navigation/MobileMenu";
import { MobileAddMenu } from "@/components/navigation/MobileAddMenu";

export const App = () => {
  return (
    <body className="text-gray-400 text-[13px] not-italic normal-nums font-normal accent-auto bg-neutral-900 box-border caret-transparent block h-full tracking-[normal] leading-[19.5px] list-outside list-disc pointer-events-auto text-start indent-[0px] normal-case visible border-separate font-inter">
      <MobileBottomNav />
      <a
        href="#ipsLayout_mainArea"
        title="Go to main content on this page"
        className="text-white box-border caret-transparent hidden hover:text-violet-500 hover:border-violet-500"
      >
        Jump to content
      </a>
      <Header />
      <Main />
      <Footer />
      <MobileMenu />
      <MobileAddMenu />
    </body>
  );
};
