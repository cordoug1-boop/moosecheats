import React from 'react';
import { X } from 'lucide-react';
import { loadStripe } from '@stripe/stripe-js';

interface PricingOption {
  duration: string;
  price: string;
  priceValue: number;
  popular?: boolean;
}

interface Product {
  id: string;
  name: string;
  image: string;
  description: string;
  price: string;
  features: string[];
  pricingOptions?: PricingOption[];
}

interface ProductDetailModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ProductDetailModal = ({ product, isOpen, onClose }: ProductDetailModalProps) => {
  const [selectedOption, setSelectedOption] = React.useState<PricingOption | null>(null);

  // Set default selected option when modal opens
  React.useEffect(() => {
    if (product?.pricingOptions && product.pricingOptions.length > 0) {
      const popularOption = product.pricingOptions.find(opt => opt.popular);
      setSelectedOption(popularOption || product.pricingOptions[0]);
    } else if (product?.price) {
      // Fallback to single price
      const priceValue = parseFloat(product.price.replace('$', ''));
      setSelectedOption({
        duration: 'Monthly',
        price: product.price,
        priceValue: priceValue
      });
    }
  }, [product]);

  if (!isOpen || !product) {
    return null;
  }

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const handleCloseClick = () => {
    onClose();
  };

  const handlePayNow = () => {
    if (!selectedOption) {
      return;
    }

    // For now, redirect to Discord for manual payment processing
    // You can replace this with actual Stripe Payment Links once created
    const discordUrl = 'https://discord.gg/gvZtKbsAkR';
    const message = `Ready to purchase ${product.name} - ${selectedOption.duration} for ${selectedOption.price}. Join our Discord to complete payment.`;
    
    if (confirm(message)) {
      window.open(discordUrl, '_blank');
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 overflow-y-auto"
      onClick={handleBackdropClick}
    >
      <div className="bg-zinc-900 rounded-2xl max-w-3xl w-full border border-white/10 shadow-2xl my-8">
        {/* Header */}
        <div className="relative">
          <img 
            src={product.image} 
            alt={product.name}
            className="w-full h-64 object-cover rounded-t-2xl"
          />
          <button
            onClick={handleCloseClick}
            className="absolute top-4 right-4 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 md:p-8">
          <h2 className="text-3xl font-bold text-white mb-4">{product.name}</h2>
          
          <p className="text-white/70 text-lg mb-6">{product.description}</p>

          {/* Features */}
          <div className="mb-8">
            <h3 className="text-xl font-semibold text-white mb-3">Features</h3>
            <ul className="space-y-2">
              {product.features.map((feature, index) => (
                <li key={index} className="flex items-start gap-2 text-white/80">
                  <span className="text-violet-500 mt-1">✓</span>
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Pricing Options */}
          {product.pricingOptions && product.pricingOptions.length > 0 && (
            <div className="mb-6">
              <h3 className="text-xl font-semibold text-white mb-3">Choose Your Plan</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {product.pricingOptions.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedOption(option)}
                    className={`relative p-4 rounded-lg border-2 transition-all ${
                      selectedOption?.duration === option.duration
                        ? 'border-violet-500 bg-violet-500/10'
                        : 'border-white/10 bg-black/20 hover:border-white/30'
                    }`}
                  >
                    {option.popular && (
                      <span className="absolute -top-2 left-1/2 -translate-x-1/2 bg-violet-500 text-white text-xs px-3 py-1 rounded-full font-semibold">
                        Popular
                      </span>
                    )}
                    <div className="text-center">
                      <div className="text-white/70 text-sm mb-1">{option.duration}</div>
                      <div className="text-2xl font-bold text-white">{option.price}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Price & Payment */}
          <div className="bg-black/30 rounded-xl p-6 border border-white/10">
            <div className="flex items-center justify-between mb-6">
              <div>
                <span className="text-3xl font-bold text-white">
                  {selectedOption?.price || product.price}
                </span>
                {selectedOption?.duration && (
                  <span className="text-sm text-white/60 ml-2">
                    {selectedOption.duration.toLowerCase()}
                  </span>
                )}
              </div>
            </div>

            <div className="space-y-4">
              {/* Pay Now Button */}
              <button
                onClick={handlePayNow}
                className="w-full bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white font-bold py-4 rounded-lg transition-all transform hover:scale-[1.02] shadow-lg flex items-center justify-center gap-2"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M13.976 9.15c-2.172-.806-3.356-1.426-3.356-2.409 0-.831.683-1.305 1.901-1.305 1.315 0 2.088.615 2.246 1.506h1.985c-.17-1.733-1.266-3.223-3.348-3.533V1.5h-2.4v1.893c-1.858.23-3.348 1.472-3.348 3.268 0 2.09 1.747 3.162 4.172 3.968 2.246.678 2.7 1.644 2.7 2.538 0 .679-.394 1.305-1.901 1.305-1.858 0-2.631-.678-2.789-1.506H6.853c.17 2.09 1.747 3.223 3.348 3.533V19.5h2.4v-1.893c1.858-.23 3.348-1.472 3.348-3.268 0-2.538-2.172-3.533-4.172-4.189z"/>
                </svg>
                Pay with Stripe
              </button>

              <div className="bg-violet-500/10 border border-violet-500/20 rounded-lg p-4">
                <h4 className="text-white font-semibold mb-2">How to Purchase</h4>
                <p className="text-white/70 text-sm mb-3">
                  Click "Pay with Stripe" to be directed to our Discord server where you can complete your secure payment with our team.
                </p>
                <div className="flex items-center gap-2 text-white/60 text-xs">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                  </svg>
                  <span>Secure payment via Discord</span>
                </div>
              </div>

              <div className="text-sm text-white/60 space-y-1">
                <p>• Include your Discord username in the payment note</p>
                <p>• Access granted within 5-10 minutes after payment verification</p>
                <p>• Contact support on Discord if you need help</p>
              </div>

              <a
                href="https://discord.gg/gvZtKbsAkR"
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full bg-violet-500 hover:bg-violet-600 text-white text-center font-bold py-3 rounded-lg transition-colors"
              >
                Join Discord for Support
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
