export const MobileAddMenu = () => {
  return (
    <div className="fixed box-border caret-transparent hidden inset-0">
      <div className="absolute bg-zinc-900 shadow-[rgba(0,0,0,0.2)_0px_0px_25px_0px] box-border caret-transparent max-w-[calc(100%_-_50px)] w-[340px] right-0 inset-y-0">
        <a
          href="#"
          className="absolute text-2xl bg-zinc-900 box-border caret-transparent block h-10 leading-9 text-center w-10 z-[2000] rounded-[40px] right-[calc(100%_+_5px)] top-[5px]"
        >
          <span className="box-border caret-transparent leading-10 font-arial">
            ×
          </span>
        </a>
        <div className="absolute box-border caret-transparent overflow-auto mb-5 p-2 inset-0 md:p-5">
          <ul className="relative box-border caret-transparent list-none w-full pl-0 pb-[102px]">
            <li className="text-sm font-bold bg-gray-400/10 box-border caret-transparent leading-[21px] p-2.5 rounded-bl rounded-br rounded-tl rounded-tr">
              Add...
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
