export const MobileBottomNav = () => {
  return (
    <div className="fixed backdrop-blur-[10px] bg-slate-800 box-border caret-transparent block w-full z-[999999] left-0 bottom-0 md:hidden">
      <ul className="items-center box-border caret-transparent flex justify-between list-none pl-0">
        <li className="box-border caret-transparent min-h-[auto] min-w-[auto] w-full md:min-h-0 md:min-w-0">
          <a
            href="/store/"
            className="relative text-white items-center box-border caret-transparent flex flex-col justify-center px-[15px] py-[25px]"
          >
            <i className="text-violet-500 font-black bg-clip-text bg-violet-500 bg-[linear-gradient(to_right,rgb(139,96,255)_0%,rgb(81,96,210)_50%,rgb(139,96,255)_100%)] bg-size-[200%] box-border caret-transparent block leading-[13px] min-h-[auto] min-w-[auto] font-font_awesome_6_pro md:min-h-0 md:min-w-0 before:accent-auto before:caret-transparent before:text-violet-500 before:text-[13px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[13px] before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro"></i>
            <span className="text-[11px] font-medium box-border caret-transparent block tracking-[1px] leading-[16.5px] min-h-[auto] min-w-[auto] uppercase mt-1 md:min-h-0 md:min-w-0">
              Store
            </span>
          </a>
        </li>
        <li className="box-border caret-transparent min-h-[auto] min-w-[auto] w-full md:min-h-0 md:min-w-0">
          <a
            href="/Status/"
            className="relative text-white items-center box-border caret-transparent flex flex-col justify-center px-[15px] py-[25px]"
          >
            <i className="text-gray-400 font-black box-border caret-transparent block leading-[13px] min-h-[auto] min-w-[auto] font-font_awesome_6_pro md:min-h-0 md:min-w-0 before:accent-auto before:caret-transparent before:text-gray-400 before:text-[13px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[13px] before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro"></i>
            <span className="text-[11px] font-medium box-border caret-transparent block tracking-[1px] leading-[16.5px] min-h-[auto] min-w-[auto] uppercase mt-1 md:min-h-0 md:min-w-0">
              Status
            </span>
          </a>
        </li>
        <li className="box-border caret-transparent min-h-[auto] min-w-[auto] w-full md:min-h-0 md:min-w-0">
          <a
            href="https://moosecheats.com/search/"
            className="relative text-white items-center box-border caret-transparent flex flex-col justify-center px-[15px] py-[25px]"
          >
            <i className="text-gray-400 font-black box-border caret-transparent block leading-[13px] min-h-[auto] min-w-[auto] font-font_awesome_6_pro md:min-h-0 md:min-w-0 before:accent-auto before:caret-transparent before:text-gray-400 before:text-[13px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[13px] before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro"></i>
            <span className="text-[11px] font-medium box-border caret-transparent block tracking-[1px] leading-[16.5px] min-h-[auto] min-w-[auto] uppercase mt-1 md:min-h-0 md:min-w-0">
              Search
            </span>
          </a>
        </li>
        <li className="box-border caret-transparent min-h-[auto] min-w-[auto] w-full md:min-h-0 md:min-w-0">
          <a
            href="https://discord.gg/gvZtKbsAkR"
            className="relative text-white items-center box-border caret-transparent flex flex-col justify-center px-[15px] py-[25px]"
          >
            <i className="text-gray-400 font-black box-border caret-transparent block leading-[13px] min-h-[auto] min-w-[auto] font-font_awesome_6_pro md:min-h-0 md:min-w-0 before:accent-auto before:caret-transparent before:text-gray-400 before:text-[13px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[13px] before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro"></i>
            <span className="text-[11px] font-medium box-border caret-transparent block tracking-[1px] leading-[16.5px] min-h-[auto] min-w-[auto] uppercase mt-1 md:min-h-0 md:min-w-0">
              Support
            </span>
          </a>
        </li>
        <li className="box-border caret-transparent min-h-[auto] min-w-[auto] w-full md:min-h-0 md:min-w-0">
          <a
            href="#"
            className="relative text-white items-center box-border caret-transparent flex flex-col justify-center px-[15px] py-[25px]"
          >
            <i className="text-gray-400 font-black box-border caret-transparent block leading-[13px] min-h-[auto] min-w-[auto] font-font_awesome_6_pro md:min-h-0 md:min-w-0 before:accent-auto before:caret-transparent before:text-gray-400 before:text-[13px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[13px] before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro"></i>
            <span className="text-[11px] font-medium box-border caret-transparent block tracking-[1px] leading-[16.5px] min-h-[auto] min-w-[auto] uppercase mt-1 md:min-h-0 md:min-w-0">
              more
            </span>
          </a>
        </li>
      </ul>
    </div>
  );
};
