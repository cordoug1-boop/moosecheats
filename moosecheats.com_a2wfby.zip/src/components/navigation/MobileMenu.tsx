export const MobileMenu = () => {
  return (
    <div className="fixed box-border caret-transparent hidden inset-0">
      <div className="absolute bg-zinc-900 shadow-[rgba(0,0,0,0.2)_0px_0px_25px_0px] box-border caret-transparent max-w-[calc(100%_-_50px)] w-[340px] right-0 inset-y-0">
        <a
          href="#"
          className="absolute text-2xl bg-zinc-900 box-border caret-transparent block h-10 leading-9 text-center w-10 z-[2000] rounded-[40px] right-[calc(100%_+_5px)] top-[5px]"
        >
          <span className="box-border caret-transparent leading-10 font-arial">
            ×
          </span>
        </a>
        <div className="absolute box-border caret-transparent flex flex-col overflow-auto inset-0">
          <ul className="box-border caret-transparent list-none pl-0 py-[15px]"></ul>
          <div className="border-b-gray-400/20 border-l-gray-400 border-r-gray-400 border-t-gray-400 box-border caret-transparent p-5 border-b">
            <ul className="box-border caret-transparent gap-x-2 flex flex-wrap-reverse list-none gap-y-2 text-center pl-0 md:gap-x-[normal] md:block md:flex-nowrap md:gap-y-[normal] md:text-start">
              <li className="box-border caret-transparent grow text-center mb-0 md:grow-0 md:text-start md:mb-[15px]">
                <a
                  href="https://moosecheats.com/login/"
                  className="text-white bg-zinc-900 box-border caret-transparent block leading-[36.79px] max-w-full text-center text-ellipsis text-nowrap align-middle w-full border border-zinc-900 overflow-hidden px-[18px] rounded-[5px] border-solid"
                >
                  Existing user? Sign In
                </a>
              </li>
              <li className="box-border caret-transparent grow text-center md:grow-0 md:text-start">
                <a
                  href="https://moosecheats.com/register/"
                  className="text-white text-base font-medium bg-violet-500 bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] bg-size-[200%] box-border caret-transparent block leading-[45.28px] max-w-full text-center text-ellipsis text-nowrap align-middle w-full overflow-hidden px-[18px] rounded-[5px]"
                >
                  Sign Up
                </a>
              </li>
            </ul>
          </div>
          <ul className="relative box-border caret-transparent grow list-none w-full pl-0 pb-[102px]">
            <li className="box-border caret-transparent">
              <a
                href="https://moosecheats.com/store/"
                className="box-border caret-transparent block px-5 py-3"
              >
                Store
              </a>
            </li>
            <li className="box-border caret-transparent">
              <a
                href="https://moosecheats.com/status/"
                className="box-border caret-transparent block px-5 py-3"
              >
                Status
              </a>
            </li>
            <li className="box-border caret-transparent">
              <a
                href="https://moosecheats.com/forums/"
                className="box-border caret-transparent block px-5 py-3"
              >
                Forums
              </a>
            </li>
            <li className="box-border caret-transparent">
              <h4 className="relative box-border caret-transparent px-5 py-3 after:accent-auto after:caret-transparent after:text-gray-400 after:block after:text-xl after:not-italic after:normal-nums after:font-normal after:tracking-[normal] after:leading-[30px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:border-separate after:right-5 after:top-2/4 after:font-fontawesome">
                <a href="#" className="box-border caret-transparent block">
                  Information
                </a>
              </h4>
              <ul className="absolute box-border caret-transparent w-full pl-0 pb-[102px] left-full top-0">
                <li className="box-border caret-transparent">
                  <a
                    href="#"
                    className="relative bg-zinc-900 box-border caret-transparent block px-5 py-3 before:accent-auto before:caret-transparent before:text-gray-400 before:text-[13px] before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-[19.5px] before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:visible before:mr-2 before:border-separate before:left-5 before:font-fontawesome"
                  >
                    Back
                  </a>
                </li>
                <li className="box-border caret-transparent">
                  <a
                    href="https://moosecheats.com/about-us/"
                    className="box-border caret-transparent block px-5 py-3"
                  >
                    About Us
                  </a>
                </li>
                <li className="box-border caret-transparent">
                  <a
                    href="https://moosecheats.com/faq/"
                    className="box-border caret-transparent block px-5 py-3"
                  >
                    FAQ
                  </a>
                </li>
                <li className="box-border caret-transparent">
                  <a
                    href="https://moosecheats.com/how-it-works/"
                    className="box-border caret-transparent block px-5 py-3"
                  >
                    How It Works
                  </a>
                </li>
                <li className="box-border caret-transparent">
                  <a
                    href="https://moosecheats.com/reviews/"
                    className="box-border caret-transparent block px-5 py-3"
                  >
                    Reviews
                  </a>
                </li>
                <li className="box-border caret-transparent">
                  <a
                    href="mailto:Moosecheats@gmail.com"
                    className="box-border caret-transparent block px-5 py-3"
                  >
                    Contact Us
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
