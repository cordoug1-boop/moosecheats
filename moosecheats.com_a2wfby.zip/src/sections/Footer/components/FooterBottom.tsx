export const FooterBottom = () => {
  return (
    <div className="border-b-gray-400 border-l-gray-400 border-r-gray-400 border-t-zinc-900 box-border caret-transparent py-[26px] border-t">
      <div className="relative items-center box-border caret-transparent gap-x-[13px] flex flex-col justify-between max-w-[1600px] gap-y-[13px] mx-auto px-[15px] md:gap-x-[normal] md:flex-row md:gap-y-[normal]">
        <div className="box-border caret-transparent">
          <ul className="box-border caret-transparent list-none pl-0">
            <li className="box-border caret-transparent inline-block align-middle mr-[15px]">
              <a
                href="#elNavTheme_menu"
                className="text-white box-border caret-transparent hover:text-violet-500 hover:border-violet-500"
              >
                Theme{" "}
                <i className="text-violet-500 font-black bg-clip-text bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] box-border caret-transparent inline-block leading-[13px] font-font_awesome_6_pro before:accent-auto before:caret-transparent before:text-violet-500 before:text-[13px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[13px] before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro"></i>
              </a>
              <ul className="absolute bg-zinc-900 shadow-[rgba(0,0,0,0.1)_0px_8px_50px_0px,rgba(0,0,0,0.05)_0px_4px_15px_0px] box-border caret-transparent hidden max-w-[375px] z-[10000] border border-zinc-900/10 pl-0 rounded-[5px] border-solid md:max-w-screen-xl before:accent-auto before:border-b-zinc-900 before:caret-transparent before:text-gray-400 before:hidden before:text-[8px] before:not-italic before:normal-nums before:font-normal before:h-0 before:tracking-[normal] before:leading-3 before:list-outside before:list-none before:pointer-events-auto before:absolute before:text-start before:indent-[0px] before:normal-case before:visible before:w-0 before:z-[100] before:border-t-transparent before:border-x-transparent before:border-separate before:border-8 before:border-solid before:font-inter after:accent-auto after:border-b-zinc-900 after:caret-transparent after:text-gray-400 after:hidden after:text-[8px] after:not-italic after:normal-nums after:font-normal after:h-0 after:tracking-[normal] after:leading-3 after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-0 after:z-[200] after:border-t-transparent after:border-x-transparent after:border-separate after:border-8 after:border-solid after:font-inter">
                <li className="border-b-gray-800 border-l-gray-400 border-r-gray-400 border-t-gray-400 box-border caret-transparent leading-[18.2px] text-left border-b">
                  <form className="box-border caret-transparent">
                    <input
                      type="hidden"
                      name="ref"
                      value="aHR0cHM6Ly9jaGVzdGVyY2hlYXRzLmNvbS9zdG9yZS8="
                      className="text-black bg-transparent box-border caret-transparent hidden text-start align-middle p-0"
                    />
                    <button
                      type="submit"
                      name="id"
                      value="7"
                      className="text-sky-600 text-sm font-bold bg-transparent caret-transparent leading-[19.6px] max-w-full text-ellipsis align-middle w-full border overflow-hidden pl-[30px] pr-5 py-[9px] rounded-[5px] border-solid border-transparent before:accent-auto before:caret-transparent before:text-sky-600 before:block before:text-sm before:not-italic before:normal-nums before:font-bold before:tracking-[normal] before:leading-[19.6px] before:list-outside before:list-none before:pointer-events-auto before:absolute before:text-left before:indent-[0px] before:normal-case before:visible before:pl-2.5 before:border-separate before:left-0 before:font-fontawesome"
                    >
                      Do not edit - Main (Default)
                    </button>
                  </form>
                </li>
                <li className="box-border caret-transparent leading-[18.2px] text-left">
                  <form className="box-border caret-transparent">
                    <input
                      type="hidden"
                      name="ref"
                      value="aHR0cHM6Ly9jaGVzdGVyY2hlYXRzLmNvbS9zdG9yZS8="
                      className="text-black bg-transparent box-border caret-transparent hidden text-start align-middle p-0"
                    />
                    <button
                      type="submit"
                      name="id"
                      value="1"
                      className="text-sky-600 text-sm bg-transparent caret-transparent leading-[19.6px] max-w-full text-ellipsis align-middle w-full border overflow-hidden pl-[30px] pr-5 py-[9px] rounded-[5px] border-solid border-transparent before:accent-auto before:caret-transparent before:text-gray-400/10 before:block before:text-sm before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-[19.6px] before:list-outside before:list-none before:pointer-events-auto before:absolute before:text-left before:indent-[0px] before:normal-case before:visible before:pl-2.5 before:border-separate before:left-0 before:font-fontawesome"
                    >
                      Default{" "}
                    </button>
                  </form>
                </li>
              </ul>
            </li>
            <li className="box-border caret-transparent inline-block align-middle mr-[15px]">
              <a
                href="https://moosecheats.com/privacy/"
                className="text-white box-border caret-transparent hover:text-violet-500 hover:border-violet-500"
              >
                Privacy Policy
              </a>
            </li>
            <li className="box-border caret-transparent inline-block align-middle mr-[15px]">
              <a
                href="mailto:Moosecheats@gmail.com"
                className="text-white box-border caret-transparent hover:text-violet-500 hover:border-violet-500"
              >
                Contact Us
              </a>
            </li>
            <li className="box-border caret-transparent inline-block align-middle">
              <a
                href="https://moosecheats.com/cookies/"
                className="text-white box-border caret-transparent hover:text-violet-500 hover:border-violet-500"
              >
                Cookies
              </a>
            </li>
          </ul>
          <p className="box-border caret-transparent clear-both hidden text-center my-[13px] md:clear-none md:text-start">
            <span className="box-border caret-transparent block text-center md:text-start"></span>
            <a
              title="Invision Community"
              href="https://www.invisioncommunity.com/"
              className="text-[10px] font-semibold box-border caret-transparent tracking-[1px] leading-[15px] text-center uppercase md:text-start"
            >
              Powered by Invision Community
            </a>
            <br className="box-border caret-transparent text-center md:text-start" />
            <a
              href="https://nullforums.net/"
              className="text-[10px] font-semibold box-border caret-transparent hidden tracking-[1px] leading-[15px] text-center uppercase md:text-start"
            >
              Invision Community Support forums
            </a>
          </p>
        </div>
        <div className="box-border caret-transparent">
          <span className="text-white items-center bg-violet-500 bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] bg-size-[200%] box-border caret-transparent flex h-10 justify-center w-10 rounded-[375px] md:rounded-[1280px]">
            <i className="font-black box-border caret-transparent block leading-[13px] font-font_awesome_6_pro before:accent-auto before:caret-transparent before:text-white before:text-[13px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[13px] before:list-outside before:list-disc before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro"></i>
          </span>
        </div>
        <a
          href="https://moosecheats.com/"
          title="moosecheats.com"
          className="text-white text-sm font-semibold box-border caret-transparent block leading-[21px] uppercase hover:text-violet-500 hover:border-violet-500"
        >
          <b className="text-violet-500 font-black bg-clip-text bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] box-border caret-transparent">
            ©
          </b>
          moosecheats
        </a>
      </div>
    </div>
  );
};
