import { FooterLogo } from "@/sections/Footer/components/FooterLogo";
import { FooterLinks } from "@/sections/Footer/components/FooterLinks";
import { TrustpilotBanner } from "@/sections/Footer/components/TrustpilotBanner";
import { PaymentLogos } from "@/sections/Footer/components/PaymentLogos";

export const FooterContent = () => {
  return (
    <div className="relative box-border caret-transparent max-w-[1600px] mx-auto px-[26px] py-[70px] md:px-[15px]">
      <div className="box-border caret-transparent gap-x-[39px] grid grid-cols-[1fr] gap-y-[39px] md:gap-x-[65px] md:grid-cols-[350px_1fr] md:gap-y-[65px]">
        <FooterLogo />
        <FooterLinks />
      </div>
      <TrustpilotBanner />
      <div className="box-border caret-transparent">
        <PaymentLogos />
      </div>
    </div>
  );
};
