export const FooterLogo = () => {
  return (
    <div className="box-border caret-transparent">
      <a
        href="https://moosecheats.com/"
        className="text-white box-border caret-transparent hover:text-violet-500 hover:border-violet-500"
      >
        <img
          src="https://c.animaapp.com/mm8t9gj9JSNds2/img/uploaded-asset-1772434164871-0.png"
          alt="Moose Cheats"
          className="box-border caret-transparent w-[200px]"
        />
      </a>
      <div className="text-white items-center bg-slate-800 box-border caret-transparent flex justify-between max-w-[250px] mt-[13px] pl-[13px] pr-[6.5px] py-[6.5px] rounded-[10px]">
        <div className="box-border caret-transparent flex flex-col leading-[13px]">
          <span className="text-gray-400 text-[10px] font-semibold box-border caret-transparent block leading-[10px] uppercase mb-[5px]">
            Contact us At
          </span>
          <strong className="font-medium box-border caret-transparent block">
            Moosecheats@gmail.com
          </strong>
        </div>
        <a
          href="mailto:Moosecheats@gmail.com"
          title="mail"
          className="items-center bg-violet-500 bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] bg-size-[200%] box-border caret-transparent flex h-10 justify-center w-10 rounded-[5px]"
        >
          <i className="font-black box-border caret-transparent block leading-[13px] font-font_awesome_6_pro before:accent-auto before:caret-transparent before:text-white before:text-[13px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[13px] before:list-outside before:list-disc before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro"></i>
        </a>
      </div>
    </div>
  );
};
