import { FooterContent } from "@/sections/Footer/components/FooterContent";
import { FooterBottom } from "@/sections/Footer/components/FooterBottom";

export const Footer = () => {
  return (
    <footer className="bg-zinc-900 box-border caret-transparent mt-[26px] pb-[85px] md:pb-0">
      <FooterContent />
      <FooterBottom />
    </footer>
  );
};
