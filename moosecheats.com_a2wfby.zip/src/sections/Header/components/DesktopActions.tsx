export const DesktopActions = () => {
  return (
    <ul className="font-bold items-center box-border caret-transparent hidden leading-[13px] list-none min-h-0 min-w-0 text-nowrap pl-0 md:flex md:min-h-[auto] md:min-w-[auto]">
      <li className="box-border caret-transparent inline-block min-h-0 min-w-0 text-nowrap align-middle mr-[15px] md:block md:min-h-[auto] md:min-w-[auto]">
        <a
          href="https://discord.gg/gvZtKbsAkR"
          title="discord"
          className="text-white text-xs items-center bg-indigo-500 box-border caret-transparent gap-x-1.5 inline-flex h-10 justify-center leading-3 gap-y-1.5 uppercase text-nowrap align-middle w-full px-3 rounded-[5px] hover:text-black hover:bg-white hover:border-black"
        >
          <i className="font-normal bg-no-repeat bg-contain box-border caret-transparent block min-h-0 min-w-0 text-nowrap bg-center font-font_awesome_6_brands md:min-h-[auto] md:min-w-[auto] before:accent-auto before:caret-transparent before:text-white before:text-xs before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-3 before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:uppercase before:text-nowrap before:visible before:border-separate before:font-font_awesome_6_brands"></i>
          Discord
        </a>
      </li>
      <ul className="items-center box-border caret-transparent hidden leading-[15px] min-h-0 min-w-0 text-nowrap pl-0 md:flex md:min-h-[auto] md:min-w-[auto]">
        <ul className="items-center box-border caret-transparent hidden min-h-0 min-w-0 text-nowrap pl-0 md:flex md:min-h-[auto] md:min-w-[auto]"></ul>
        <li className="box-border caret-transparent hidden text-nowrap align-middle mr-[15px]"></li>
        <li className="box-border caret-transparent hidden h-[25px] text-nowrap align-middle w-0 border-gray-800 mr-[15px] border-r"></li>
        <li className="box-border caret-transparent inline-block min-h-0 min-w-0 text-nowrap align-middle mr-[15px] md:block md:min-h-[auto] md:min-w-[auto]">
          <a
            href="https://moosecheats.com/login/"
            className="text-white font-medium bg-zinc-900 bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] box-border caret-transparent inline-block leading-[13px] max-w-full text-center text-ellipsis text-nowrap align-middle overflow-hidden px-5 py-2.5 rounded-[5px]"
          >
            Existing user? Sign In  
            <i className="text-[15px] font-black box-border caret-transparent inline-block leading-[15px] text-nowrap font-font_awesome_6_pro before:accent-auto before:caret-transparent before:text-white before:text-[15px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[15px] before:list-outside before:list-none before:pointer-events-auto before:text-center before:indent-[0px] before:normal-case before:text-nowrap before:visible before:border-separate before:font-font_awesome_6_pro"></i>
          </a>
          <div className="absolute bg-zinc-900 shadow-[rgba(0,0,0,0.1)_0px_8px_50px_0px,rgba(0,0,0,0.05)_0px_4px_15px_0px] box-border caret-transparent hidden max-w-[560px] min-w-[200px] text-nowrap z-[10000] border border-zinc-900/10 rounded-[5px] border-solid before:accent-auto before:border-b-zinc-900 before:caret-transparent before:text-gray-400 before:hidden before:text-[8px] before:not-italic before:normal-nums before:font-bold before:h-0 before:tracking-[normal] before:leading-[15px] before:list-outside before:list-none before:pointer-events-auto before:absolute before:text-start before:indent-[0px] before:normal-case before:text-nowrap before:visible before:w-0 before:z-[100] before:border-t-transparent before:border-x-transparent before:border-separate before:border-8 before:border-solid before:font-inter after:accent-auto after:border-b-zinc-900 after:caret-transparent after:text-gray-400 after:hidden after:text-[8px] after:not-italic after:normal-nums after:font-bold after:h-0 after:tracking-[normal] after:leading-[15px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:text-nowrap after:visible after:w-0 after:z-[200] after:border-t-transparent after:border-x-transparent after:border-separate after:border-8 after:border-solid after:font-inter">
            <form className="box-border caret-transparent text-nowrap">
              <input
                type="hidden"
                name="csrfKey"
                value="4bfd6cadde89a219296d01338f5afab2"
                className="text-black font-normal bg-transparent box-border caret-transparent hidden text-nowrap align-middle p-0"
              />
              <input
                type="hidden"
                name="ref"
                value="aHR0cHM6Ly9jaGVzdGVyY2hlYXRzLmNvbS9zdG9yZS8="
                className="text-black font-normal bg-transparent box-border caret-transparent hidden text-nowrap align-middle p-0"
              />
              <div className="box-border caret-transparent text-nowrap">
                <div className="box-border caret-transparent text-nowrap p-2 md:p-5">
                  <h4 className="text-lg box-border caret-transparent inline-block leading-6 text-nowrap font-inter">
                    Sign In
                  </h4>
                  <br className="box-border caret-transparent text-nowrap" />
                  <br className="box-border caret-transparent text-nowrap" />
                  <ul className="box-border caret-transparent text-nowrap pl-0">
                    <li className="box-border caret-transparent text-nowrap mb-[15px]">
                      <input
                        type="email"
                        placeholder="Email Address"
                        name="auth"
                        className="text-base font-normal bg-zinc-900 box-border caret-transparent max-w-full text-nowrap align-middle w-full border border-gray-400/40 p-2 rounded-bl rounded-br rounded-tl rounded-tr border-solid md:text-[13px]"
                      />
                    </li>
                    <li className="box-border caret-transparent text-nowrap mb-[15px]">
                      <input
                        type="password"
                        placeholder="Password"
                        name="password"
                        className="text-base font-normal bg-zinc-900 box-border caret-transparent max-w-full text-nowrap align-middle w-full border border-gray-400/40 p-2 rounded-bl rounded-br rounded-tl rounded-tr border-solid md:text-[13px]"
                      />
                    </li>
                    <li className="box-border caret-transparent text-nowrap mb-[15px]">
                      <span className="relative text-[0px] box-border caret-transparent block float-left h-4 text-nowrap align-middle w-4 mt-[3px]">
                        <span className="absolute text-white bg-clip-padding bg-violet-500 box-border caret-transparent block pointer-events-none text-nowrap border border-violet-500 rounded-bl rounded-br rounded-tl rounded-tr border-solid inset-0 after:accent-auto after:items-center after:caret-transparent after:text-white after:flex after:text-[9px] after:not-italic after:normal-nums after:font-bold after:justify-center after:tracking-[normal] after:leading-[15px] after:list-outside after:list-none after:pointer-events-none after:absolute after:text-start after:indent-[0px] after:normal-case after:text-nowrap after:visible after:border-separate after:inset-0 after:font-fontawesome"></span>
                      </span>
                      <div className="box-border caret-transparent text-nowrap ml-6">
                        <label className="box-border caret-transparent block text-nowrap align-middle">
                          Remember me
                        </label>
                        <span className="text-xs box-border caret-transparent block text-nowrap mt-[3px]">
                          Not recommended on shared computers
                        </span>
                      </div>
                    </li>
                    <li className="box-border caret-transparent text-nowrap mt-[15px]">
                      <button
                        type="submit"
                        name="_processLogin"
                        value="usernamepassword"
                        className="text-white font-medium bg-zinc-900 bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] caret-transparent leading-[36.79px] max-w-full text-center text-ellipsis text-nowrap align-middle w-full overflow-hidden px-[18px] py-0 rounded-[5px]"
                      >
                        Sign In
                      </button>
                      <p className="text-xs box-border caret-transparent leading-[17.4px] text-right text-nowrap my-3">
                        <a
                          href="https://moosecheats.com/lostpassword/"
                          className="text-white box-border caret-transparent text-nowrap hover:text-violet-500 hover:border-violet-500"
                        >
                          Forgot your password?
                        </a>
                      </p>
                    </li>
                  </ul>
                </div>
              </div>
            </form>
          </div>
        </li>
        <li className="box-border caret-transparent inline-block min-h-0 min-w-0 text-nowrap align-middle md:block md:min-h-[auto] md:min-w-[auto]">
          <a
            href="https://moosecheats.com/register/"
            className="text-white font-medium bg-zinc-900 bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] box-border caret-transparent inline-block leading-[13px] max-w-full text-center text-ellipsis text-nowrap align-middle overflow-hidden px-5 py-2.5 rounded-[5px]"
          >
            Sign Up
          </a>
        </li>
      </ul>
    </ul>
  );
};
