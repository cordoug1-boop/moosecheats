import { SearchBar } from "@/sections/Header/components/SearchBar";

export const DesktopNav = () => {
  return (
    <div className="relative box-border caret-transparent hidden h-[85px] z-10 md:block">
      <div className="relative items-center box-border caret-transparent flex h-full justify-between max-w-[1600px] mx-auto px-[15px]">
        <nav className="relative items-center bg-zinc-900 shadow-[rgba(0,0,0,0.1)_0px_5px_10px_0px] box-border caret-transparent hidden h-full justify-between min-h-0 min-w-0 w-full px-[13px] rounded-[10px] md:flex md:min-h-[auto] md:min-w-[auto]">
          <div className="relative items-center box-border caret-transparent flex h-full justify-between min-h-0 min-w-0 w-full z-[2000] md:min-h-[auto] md:min-w-[auto]">
            <ul className="box-border caret-transparent grow h-full list-none min-h-0 pl-0 md:min-h-[auto]">
              <li className="relative items-center box-border caret-transparent hidden float-left h-full md:flex">
                <a
                  href="https://moosecheats.com/store/"
                  className="relative text-white text-[13px] font-normal items-center box-border caret-transparent gap-x-[6.5px] flex h-auto justify-normal leading-[18.2px] min-h-0 min-w-0 gap-y-[6.5px] text-left text-ellipsis text-nowrap z-auto overflow-hidden p-[16.25px] rounded-t-[5px] md:text-[15px] md:font-semibold md:gap-x-[normal] md:h-full md:justify-center md:leading-[15px] md:min-h-[auto] md:min-w-[auto] md:gap-y-[normal] md:text-center md:text-clip md:text-wrap md:z-[1] md:overflow-visible md:px-[18.75px] md:py-0 md:rounded-t-none before:md:accent-auto before:md:bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] before:md:shadow-[rgb(139,96,255)_0px_3px_10px_0px] before:md:caret-transparent before:md:text-white before:md:block before:md:text-[15px] before:md:not-italic before:md:normal-nums before:md:font-semibold before:md:h-px before:md:tracking-[normal] before:md:leading-[15px] before:md:list-outside before:md:list-none before:md:pointer-events-auto before:md:absolute before:md:text-center before:md:no-underline before:md:indent-[0px] before:md:normal-case before:md:visible before:md:w-[35px] before:md:border-separate before:md:top-0 before:md:font-inter after:md:accent-auto after:md:bg-slate-800 after:md:caret-transparent after:md:text-white after:md:block after:md:text-[15px] after:md:not-italic after:md:normal-nums after:md:font-semibold after:md:h-5 after:md:tracking-[normal] after:md:leading-[15px] after:md:list-outside after:md:list-none after:md:pointer-events-auto after:md:absolute after:md:text-center after:md:no-underline after:md:indent-[0px] after:md:normal-case after:md:visible after:md:w-px after:md:border-separate after:md:right-0 after:md:font-inter hover:bg-transparent"
                >
                  <div className="text-[13px] font-normal box-border caret-transparent leading-[18.2px] min-h-0 min-w-0 text-left text-nowrap mr-0 md:text-base md:font-semibold md:leading-4 md:min-h-[auto] md:min-w-[auto] md:text-center md:text-wrap md:mr-2">
                    <i className="text-white text-[13px] font-black bg-clip-border bg-none box-border caret-transparent inline-block leading-[13px] text-left text-nowrap font-font_awesome_6_pro md:text-violet-500 md:text-base md:bg-clip-text md:bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] md:leading-4 md:text-center md:text-wrap before:accent-auto before:caret-transparent before:text-white before:text-[13px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[13px] before:list-outside before:list-none before:pointer-events-auto before:text-left before:indent-[0px] before:normal-case before:text-nowrap before:visible before:border-separate before:font-font_awesome_6_pro before:md:text-violet-500 before:md:text-base before:md:leading-4 before:md:text-center before:md:text-wrap"></i>
                  </div>
                  <span className="text-[13px] font-normal box-border caret-transparent block leading-[18.2px] min-h-0 min-w-0 text-left text-nowrap md:text-[15px] md:font-semibold md:leading-[15px] md:min-h-[auto] md:min-w-[auto] md:text-center md:text-wrap">
                    Store
                  </span>
                </a>
              </li>
              <li className="relative items-center box-border caret-transparent hidden float-left h-full md:flex">
                <a
                  href="https://moosecheats.com/status/"
                  className="relative text-white text-[13px] items-center box-border caret-transparent gap-x-[6.5px] flex h-auto justify-normal leading-[18.2px] min-h-0 min-w-0 gap-y-[6.5px] text-left text-ellipsis text-nowrap z-auto overflow-hidden p-[16.25px] md:text-[15px] md:gap-x-[normal] md:h-full md:justify-center md:leading-[15px] md:min-h-[auto] md:min-w-[auto] md:gap-y-[normal] md:text-center md:text-clip md:text-wrap md:z-[1] md:overflow-visible md:px-[18.75px] md:py-0 before:md:accent-auto before:md:bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] before:md:shadow-[rgb(139,96,255)_0px_3px_10px_0px] before:md:caret-transparent before:md:text-white before:md:block before:md:text-[15px] before:md:not-italic before:md:normal-nums before:md:font-normal before:md:h-px before:md:tracking-[normal] before:md:leading-[15px] before:md:list-outside before:md:list-none before:md:pointer-events-auto before:md:absolute before:md:text-center before:md:no-underline before:md:indent-[0px] before:md:normal-case before:md:visible before:md:w-0 before:md:border-separate before:md:top-0 before:md:font-inter after:md:accent-auto after:md:bg-slate-800 after:md:caret-transparent after:md:text-white after:md:block after:md:text-[15px] after:md:not-italic after:md:normal-nums after:md:font-normal after:md:h-5 after:md:tracking-[normal] after:md:leading-[15px] after:md:list-outside after:md:list-none after:md:pointer-events-auto after:md:absolute after:md:text-center after:md:no-underline after:md:indent-[0px] after:md:normal-case after:md:visible after:md:w-px after:md:border-separate after:md:right-0 after:md:font-inter hover:bg-transparent"
                >
                  <div className="text-[13px] box-border caret-transparent leading-[18.2px] min-h-0 min-w-0 text-left text-nowrap mr-0 md:text-base md:leading-4 md:min-h-[auto] md:min-w-[auto] md:text-center md:text-wrap md:mr-2">
                    <i className="text-white text-[13px] font-black box-border caret-transparent inline-block leading-[13px] text-left text-nowrap font-font_awesome_6_pro md:text-gray-400 md:text-base md:leading-4 md:text-center md:text-wrap before:accent-auto before:caret-transparent before:text-white before:text-[13px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[13px] before:list-outside before:list-none before:pointer-events-auto before:text-left before:indent-[0px] before:normal-case before:text-nowrap before:visible before:border-separate before:font-font_awesome_6_pro before:md:text-gray-400 before:md:text-base before:md:leading-4 before:md:text-center before:md:text-wrap"></i>
                  </div>
                  <span className="text-[13px] box-border caret-transparent block leading-[18.2px] min-h-0 min-w-0 text-left text-nowrap md:text-[15px] md:leading-[15px] md:min-h-[auto] md:min-w-[auto] md:text-center md:text-wrap">
                    Status
                  </span>
                </a>
              </li>
              <li className="relative items-center box-border caret-transparent hidden float-left h-full md:flex">
                <a
                  href="https://moosecheats.com/forums/"
                  className="relative text-white text-[13px] items-center box-border caret-transparent gap-x-[6.5px] flex h-auto justify-normal leading-[18.2px] min-h-0 min-w-0 gap-y-[6.5px] text-left text-ellipsis text-nowrap z-auto overflow-hidden p-[16.25px] md:text-[15px] md:gap-x-[normal] md:h-full md:justify-center md:leading-[15px] md:min-h-[auto] md:min-w-[auto] md:gap-y-[normal] md:text-center md:text-clip md:text-wrap md:z-[1] md:overflow-visible md:px-[18.75px] md:py-0 before:md:accent-auto before:md:bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] before:md:shadow-[rgb(139,96,255)_0px_3px_10px_0px] before:md:caret-transparent before:md:text-white before:md:block before:md:text-[15px] before:md:not-italic before:md:normal-nums before:md:font-normal before:md:h-px before:md:tracking-[normal] before:md:leading-[15px] before:md:list-outside before:md:list-none before:md:pointer-events-auto before:md:absolute before:md:text-center before:md:no-underline before:md:indent-[0px] before:md:normal-case before:md:visible before:md:w-0 before:md:border-separate before:md:top-0 before:md:font-inter after:md:accent-auto after:md:bg-slate-800 after:md:caret-transparent after:md:text-white after:md:block after:md:text-[15px] after:md:not-italic after:md:normal-nums after:md:font-normal after:md:h-5 after:md:tracking-[normal] after:md:leading-[15px] after:md:list-outside after:md:list-none after:md:pointer-events-auto after:md:absolute after:md:text-center after:md:no-underline after:md:indent-[0px] after:md:normal-case after:md:visible after:md:w-px after:md:border-separate after:md:right-0 after:md:font-inter hover:bg-transparent"
                >
                  <div className="text-[13px] box-border caret-transparent leading-[18.2px] min-h-0 min-w-0 text-left text-nowrap mr-0 md:text-base md:leading-4 md:min-h-[auto] md:min-w-[auto] md:text-center md:text-wrap md:mr-2">
                    <i className="text-white text-[13px] font-black box-border caret-transparent inline-block leading-[13px] text-left text-nowrap font-font_awesome_6_pro md:text-gray-400 md:text-base md:leading-4 md:text-center md:text-wrap before:accent-auto before:caret-transparent before:text-white before:text-[13px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[13px] before:list-outside before:list-none before:pointer-events-auto before:text-left before:indent-[0px] before:normal-case before:text-nowrap before:visible before:border-separate before:font-font_awesome_6_pro before:md:text-gray-400 before:md:text-base before:md:leading-4 before:md:text-center before:md:text-wrap"></i>
                  </div>
                  <span className="text-[13px] box-border caret-transparent block leading-[18.2px] min-h-0 min-w-0 text-left text-nowrap md:text-[15px] md:leading-[15px] md:min-h-[auto] md:min-w-[auto] md:text-center md:text-wrap">
                    Forums
                  </span>
                </a>
              </li>
              <li className="relative items-center box-border caret-transparent hidden float-left h-full md:flex">
                <a
                  href="#"
                  className="relative text-white text-[13px] items-center box-border caret-transparent gap-x-[6.5px] flex h-auto justify-normal leading-[18.2px] min-h-0 min-w-0 gap-y-[6.5px] text-left text-ellipsis text-nowrap z-auto overflow-hidden pl-[16.25px] pr-[25px] py-[16.25px] rounded-b-[5px] md:text-[15px] md:gap-x-[normal] md:h-full md:justify-center md:leading-[15px] md:min-h-[auto] md:min-w-[auto] md:gap-y-[normal] md:text-center md:text-clip md:text-wrap md:z-[1] md:overflow-visible md:px-[18.75px] md:py-0 md:rounded-b-none before:md:accent-auto before:md:bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] before:md:shadow-[rgb(139,96,255)_0px_3px_10px_0px] before:md:caret-transparent before:md:text-white before:md:block before:md:text-[15px] before:md:not-italic before:md:normal-nums before:md:font-normal before:md:h-px before:md:tracking-[normal] before:md:leading-[15px] before:md:list-outside before:md:list-none before:md:pointer-events-auto before:md:absolute before:md:text-center before:md:no-underline before:md:indent-[0px] before:md:normal-case before:md:visible before:md:w-0 before:md:border-separate before:md:top-0 before:md:font-inter hover:bg-transparent"
                >
                  <div className="text-[13px] box-border caret-transparent leading-[18.2px] min-h-0 min-w-0 text-left text-nowrap mr-0 md:text-base md:leading-4 md:min-h-[auto] md:min-w-[auto] md:text-center md:text-wrap md:mr-2"></div>
                  <span className="text-[13px] box-border caret-transparent block leading-[18.2px] min-h-0 min-w-0 text-left text-nowrap md:text-[15px] md:leading-[15px] md:min-h-[auto] md:min-w-[auto] md:text-center md:text-wrap">
                    Information{" "}
                    <i className="text-white text-[13px] font-black box-border caret-transparent inline-block leading-[13px] text-left text-nowrap font-font_awesome_6_pro md:text-gray-400 md:text-[15px] md:leading-[15px] md:text-center md:text-wrap before:accent-auto before:caret-transparent before:text-white before:text-[13px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[13px] before:list-outside before:list-none before:pointer-events-auto before:text-left before:indent-[0px] before:normal-case before:text-nowrap before:visible before:border-separate before:font-font_awesome_6_pro before:md:text-gray-400 before:md:text-[15px] before:md:leading-[15px] before:md:text-center before:md:text-wrap"></i>
                  </span>
                </a>
                <ul className="absolute bg-zinc-900 shadow-[rgba(0,0,0,0.1)_0px_8px_50px_0px,rgba(0,0,0,0.05)_0px_4px_15px_0px] box-border caret-transparent hidden leading-[18.2px] mt-[-3px] max-w-[500px] min-w-[200px] text-left z-[10000] border border-zinc-900/10 pl-0 rounded-[5px] border-solid md:leading-[19.5px] md:text-start before:accent-auto before:border-b-zinc-900 before:caret-transparent before:text-gray-400 before:hidden before:text-[8px] before:not-italic before:normal-nums before:font-normal before:h-0 before:tracking-[normal] before:leading-[11.2px] before:list-outside before:list-none before:pointer-events-auto before:absolute before:text-left before:indent-[0px] before:normal-case before:visible before:w-0 before:z-[100] before:border-t-transparent before:border-x-transparent before:border-separate before:border-8 before:border-solid before:font-inter before:md:leading-3 before:md:text-start after:accent-auto after:border-b-zinc-900 after:caret-transparent after:text-gray-400 after:hidden after:text-[8px] after:not-italic after:normal-nums after:font-normal after:h-0 after:tracking-[normal] after:leading-[11.2px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-left after:indent-[0px] after:normal-case after:visible after:w-0 after:z-[200] after:border-t-transparent after:border-x-transparent after:border-separate after:border-8 after:border-solid after:font-inter after:md:leading-3 after:md:text-start">
                  <li className="border-b-gray-800 border-l-gray-400 border-r-gray-400 border-t-gray-400 box-border caret-transparent leading-[18.2px] text-left border-b">
                    <a
                      href="https://moosecheats.com/about-us/"
                      className="relative text-white box-border caret-transparent block text-ellipsis text-nowrap overflow-hidden p-[16.25px] rounded-[5px] md:rounded-b-none hover:bg-gray-800"
                    >
                      About Us
                    </a>
                  </li>
                  <li className="border-b-gray-800 border-l-gray-400 border-r-gray-400 border-t-gray-400 box-border caret-transparent leading-[18.2px] text-left border-b">
                    <a
                      href="https://moosecheats.com/faq/"
                      className="relative text-white box-border caret-transparent block text-ellipsis text-nowrap overflow-hidden p-[16.25px] rounded-b-[5px] md:rounded-b-none hover:bg-gray-800"
                    >
                      FAQ
                    </a>
                  </li>
                  <li className="border-b-gray-800 border-l-gray-400 border-r-gray-400 border-t-gray-400 box-border caret-transparent leading-[18.2px] text-left border-b">
                    <a
                      href="https://moosecheats.com/how-it-works/"
                      className="relative text-white box-border caret-transparent block text-ellipsis text-nowrap overflow-hidden p-[16.25px] rounded-b-[5px] md:rounded-b-none hover:bg-gray-800"
                    >
                      How It Works
                    </a>
                  </li>
                  <li className="border-b-gray-800 border-l-gray-400 border-r-gray-400 border-t-gray-400 box-border caret-transparent leading-[18.2px] text-left border-b">
                    <a
                      href="https://moosecheats.com/reviews/"
                      className="relative text-white box-border caret-transparent block text-ellipsis text-nowrap overflow-hidden p-[16.25px] rounded-b-[5px] md:rounded-b-none hover:bg-gray-800"
                    >
                      Reviews
                    </a>
                  </li>
                  <li className="box-border caret-transparent leading-[18.2px] text-left">
                    <a
                      href="mailto:Moosecheats@gmail.com"
                      className="relative text-white box-border caret-transparent block text-ellipsis text-nowrap overflow-hidden p-[16.25px] rounded-b-[5px] hover:bg-gray-800"
                    >
                      Contact Us
                    </a>
                  </li>
                </ul>
              </li>
              <li className="relative items-center box-border caret-transparent flex float-left h-full md:hidden">
                <a
                  href="#"
                  className="relative text-white text-[15px] items-center box-border caret-transparent flex h-full justify-center leading-[15px] text-center z-[1] px-[18.75px] before:accent-auto before:bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] before:shadow-[rgb(139,96,255)_0px_3px_10px_0px] before:caret-transparent before:text-white before:block before:text-[15px] before:not-italic before:normal-nums before:font-normal before:h-px before:tracking-[normal] before:leading-[15px] before:list-outside before:list-none before:pointer-events-auto before:absolute before:text-center before:indent-[0px] before:normal-case before:visible before:w-0 before:border-separate before:top-0 before:font-inter"
                >
                  More
                  <i className="text-gray-400 font-black box-border caret-transparent block font-font_awesome_6_pro before:accent-auto before:caret-transparent before:text-gray-400 before:text-[15px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[15px] before:list-outside before:list-none before:pointer-events-auto before:text-center before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro"></i>
                </a>
                <ul className="absolute bg-zinc-900 shadow-[rgba(0,0,0,0.1)_0px_8px_50px_0px,rgba(0,0,0,0.05)_0px_4px_15px_0px] box-border caret-transparent hidden mt-[-3px] max-w-[500px] min-w-[200px] z-[10000] border border-zinc-900/10 pl-0 rounded-[5px] border-solid before:accent-auto before:border-b-zinc-900 before:caret-transparent before:text-gray-400 before:hidden before:text-[8px] before:not-italic before:normal-nums before:font-normal before:h-0 before:tracking-[normal] before:leading-3 before:list-outside before:list-none before:pointer-events-auto before:absolute before:text-start before:indent-[0px] before:normal-case before:visible before:w-0 before:z-[100] before:border-t-transparent before:border-x-transparent before:border-separate before:border-8 before:border-solid before:font-inter after:accent-auto after:border-b-zinc-900 after:caret-transparent after:text-gray-400 after:hidden after:text-[8px] after:not-italic after:normal-nums after:font-normal after:h-0 after:tracking-[normal] after:leading-3 after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-0 after:z-[200] after:border-t-transparent after:border-x-transparent after:border-separate after:border-8 after:border-solid after:font-inter"></ul>
                <ul className="absolute box-border caret-transparent hidden z-[1000] pl-0 top-full inset-x-0">
                  <li className="relative box-border caret-transparent hidden float-left">
                    <a
                      href="#"
                      className="relative text-gray-400/60 box-border caret-transparent block float-left leading-[50px] text-center px-[18px] hover:text-gray-400 hover:border-gray-400"
                    >
                      More{" "}
                      <i className="font-black box-border caret-transparent inline-block leading-[13px] font-font_awesome_6_pro before:accent-auto before:caret-transparent before:text-gray-400/60 before:text-[13px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[13px] before:list-outside before:list-none before:pointer-events-auto before:text-center before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro"></i>
                    </a>
                  </li>
                </ul>
              </li>
            </ul>
            <div className="relative items-center border-b-gray-400 border-l-gray-800 border-r-gray-400 border-t-gray-400 box-border caret-transparent flex h-full justify-center min-h-0 min-w-0 pl-[19.5px] border-l md:min-h-[auto] md:min-w-[auto]">
              <SearchBar />
            </div>
          </div>
        </nav>
        <ul className="relative items-center bg-zinc-900 box-border caret-transparent flex justify-end list-none my-0 pl-0 md:static md:[align-items:normal] md:bg-transparent md:hidden md:justify-normal md:list-disc md:my-[13px] md:pl-10">
          <li className="box-border caret-transparent list-none md:list-disc">
            <a
              href="https://moosecheats.com/discover/"
              className="relative text-gray-400 text-[22px] box-border caret-transparent block h-[50px] leading-[50px] list-none opacity-70 text-center w-11 md:static md:text-white md:text-[13px] md:inline md:h-auto md:leading-[19.5px] md:list-disc md:opacity-100 md:text-start md:w-auto hover:text-violet-500 hover:border-violet-500"
            >
              <i className="text-gray-400 text-[22px] font-black box-border caret-transparent inline-block leading-[22px] list-none text-center font-font_awesome_6_pro md:text-white md:text-[13px] md:leading-[13px] md:list-disc md:text-start before:accent-auto before:caret-transparent before:text-gray-400 before:text-[22px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[22px] before:list-outside before:list-none before:pointer-events-auto before:text-center before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro before:md:text-white before:md:text-[13px] before:md:leading-[13px] before:md:list-disc before:md:text-start"></i>
            </a>
          </li>
          <li className="box-border caret-transparent list-none md:list-disc">
            <a
              href="https://moosecheats.com/search/"
              className="relative text-gray-400 text-[22px] box-border caret-transparent block h-[50px] leading-[50px] list-none opacity-70 text-center w-11 md:static md:text-white md:text-[13px] md:inline md:h-auto md:leading-[19.5px] md:list-disc md:opacity-100 md:text-start md:w-auto hover:text-violet-500 hover:border-violet-500"
            >
              <i className="text-gray-400 text-[22px] font-black box-border caret-transparent inline-block leading-[22px] list-none text-center font-font_awesome_6_pro md:text-white md:text-[13px] md:leading-[13px] md:list-disc md:text-start before:accent-auto before:caret-transparent before:text-gray-400 before:text-[22px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[22px] before:list-outside before:list-none before:pointer-events-auto before:text-center before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro before:md:text-white before:md:text-[13px] before:md:leading-[13px] before:md:list-disc before:md:text-start"></i>
            </a>
          </li>
        </ul>
      </div>
    </div>
  );
};
