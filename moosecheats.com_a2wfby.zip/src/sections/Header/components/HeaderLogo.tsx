export const HeaderLogo = () => {
  return (
    <a
      href="https://moosecheats.com/"
      className="text-white box-border caret-transparent block hover:text-violet-500 hover:border-violet-500"
    >
      <img
        src="https://c.animaapp.com/mm8t9gj9JSNds2/img/uploaded-asset-1772434164871-0.png"
        alt="Moose Cheats"
        className="box-border caret-transparent max-h-[75px]"
      />
    </a>
  );
};
