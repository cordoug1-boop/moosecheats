export const MobileCart = () => {
  return (
    <div className="items-center bg-zinc-900 box-border caret-transparent flex h-10 justify-center min-h-[auto] min-w-[auto] p-[5px] rounded-[10px] md:hidden md:min-h-0 md:min-w-0">
      <i className="text-violet-500 font-black items-center border-b-violet-500 border-l-violet-500 border-r-gray-800 border-t-violet-500 box-border caret-transparent flex h-3/6 justify-center leading-[13px] min-h-[auto] min-w-[auto] w-[30px] mr-[13px] border-r font-font_awesome_6_pro md:min-h-0 md:min-w-0">
        $
      </i>
      <div className="box-border caret-transparent min-h-[auto] min-w-[auto] md:min-h-0 md:min-w-0">
        <span className="text-white box-border caret-transparent">0</span>.
        <span className="box-border caret-transparent">00 USD</span>
      </div>
      <a
        href="/clients/credit/?do=topup"
        className="text-violet-500 items-center bg-violet-500/20 box-border caret-transparent flex h-full justify-center min-h-[auto] min-w-[auto] w-[30px] ml-[13px] rounded-lg md:min-h-0 md:min-w-0 hover:text-black hover:bg-violet-500 hover:border-black"
      >
        <i className="font-black box-border caret-transparent block leading-[13px] min-h-[auto] min-w-[auto] font-font_awesome_6_pro md:min-h-0 md:min-w-0 before:accent-auto before:caret-transparent before:text-violet-500 before:text-[13px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[13px] before:list-outside before:list-disc before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro"></i>
      </a>
    </div>
  );
};
