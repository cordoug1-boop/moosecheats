export const OnlineIndicator = () => {
  return (
    <div className="box-border caret-transparent ml-[26px]">
      <a
        href=""
        className="text-white items-center box-border caret-transparent gap-x-[9.75px] inline-flex gap-y-[9.75px] hover:text-violet-500 hover:border-violet-500"
      >
        <span className="text-[26px] bg-clip-text bg-[linear-gradient(to_right,rgb(15,81,43),rgb(42,189,105),rgb(15,81,43))] box-border caret-transparent block leading-[26px] mt-1">
          <i className="box-border caret-transparent inline-block font-font_awesome_6_pro before:accent-auto before:caret-transparent before:text-white before:text-[26px] before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-[26px] before:list-outside before:list-disc before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro"></i>
        </span>
        <div className="text-[11px] box-border caret-transparent gap-x-[5.5px] flex flex-col leading-[11px] gap-y-[5.5px]">
          <span className="text-green-500 text-base font-bold box-border caret-transparent block leading-4">
            1213
          </span>
          <span className="text-[9px] font-medium box-border caret-transparent block leading-[9px] uppercase">
            Online
          </span>
        </div>
      </a>
    </div>
  );
};
