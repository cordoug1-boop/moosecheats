export const SearchBar = () => {
  return (
    <div className="relative text-neutral-800 bg-zinc-900 shadow-[rgba(0,0,0,0.05)_0px_0px_10px_0px] box-border caret-transparent hidden h-[50px] min-h-0 min-w-0 w-[350px] z-[1] border border-gray-800 rounded-[5px] border-solid md:block md:min-h-[auto] md:min-w-[auto]">
      <form className="box-border caret-transparent flex h-full py-[6.5px] rounded-[5px]">
        <button
          type="submit"
          aria-label="Search"
          className="items-center bg-transparent caret-transparent flex shrink-0 justify-center min-h-0 min-w-0 text-center align-middle px-4 py-0 rounded-r-[5px] md:min-h-[auto] md:min-w-[auto]"
        >
          <img
            src="https://c.animaapp.com/mm8t9gj9JSNds2/assets/icon-1.svg"
            alt="Icon"
            className="box-border caret-transparent h-5 w-5"
          />
        </button>
        <input
          type="search"
          placeholder="Search..."
          name="q"
          aria-label="Search"
          className="text-white bg-transparent box-border caret-transparent block basis-full grow leading-[13px] min-h-0 -outline-offset-2 align-middle w-full pl-0 pr-4 py-0 rounded-bl rounded-br rounded-tl rounded-tr md:min-h-[auto]"
        />
        <details className="relative text-gray-400 text-xs bg-white/0 box-border caret-transparent shrink-0 leading-[18px] min-h-0 min-w-0 border border-violet-500/20 my-1.5 p-2.5 rounded-lg border-solid md:min-h-[auto] md:min-w-[auto]">
          <summary className="relative text-white text-[13px] font-medium items-center bg-gray-800 box-border caret-transparent flex h-full leading-[13px] list-inside list-[disclosure-closed] mr-[6.5px] px-[13px] py-[6.5px] rounded-[5px] after:accent-auto after:caret-transparent after:text-white after:block after:text-[13px] after:not-italic after:normal-nums after:font-medium after:h-0 after:tracking-[normal] after:leading-[13px] after:list-inside after:list-[disclosure-closed] after:min-h-0 after:min-w-0 after:pointer-events-none after:text-start after:indent-[0px] after:normal-case after:visible after:w-0 after:ml-[7.8px] after:border-t-white after:border-t-4 after:border-b-transparent after:border-x-transparent after:border-x-4 after:border-separate after:border-solid after:font-inter after:md:min-h-[auto] after:md:min-w-[auto]">
            Everywhere
          </summary>
          <ul className="absolute bg-zinc-900 shadow-[rgba(0,0,0,0.15)_0px_10px_25px_0px,rgba(0,0,0,0.1)_0px_1px_2px_0px] box-border caret-transparent list-none min-w-[180px] text-nowrap p-[5px] rounded-bl rounded-br rounded-tl rounded-tr right-0 top-[calc(100%_+_7px)] before:accent-auto before:border-b-zinc-900 before:caret-transparent before:text-gray-400 before:block before:text-xs before:not-italic before:normal-nums before:font-normal before:h-0 before:tracking-[normal] before:leading-[18px] before:list-outside before:list-none before:pointer-events-none before:absolute before:text-start before:indent-[0px] before:normal-case before:text-nowrap before:visible before:w-0 before:border-t-transparent before:border-b-4 before:border-x-transparent before:border-x-4 before:border-separate before:border-solid before:right-3 before:bottom-full before:font-inter">
            <li className="box-border caret-transparent text-nowrap">
              <label className="relative box-border caret-transparent block text-nowrap align-middle">
                <span className="text-white bg-zinc-900 box-border caret-transparent block text-nowrap p-[7.2px] rounded-bl rounded-br rounded-tl rounded-tr before:accent-auto before:caret-transparent before:text-white before:inline-block before:text-xs before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-3 before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:text-nowrap before:visible before:w-[18px] before:border-separate before:font-fontawesome">
                  Everywhere
                </span>
              </label>
            </li>
            <li className="box-border caret-transparent text-nowrap">
              <label className="relative box-border caret-transparent block text-nowrap align-middle">
                <span className="box-border caret-transparent block text-nowrap p-[7.2px] rounded-bl rounded-br rounded-tl rounded-tr before:accent-auto before:caret-transparent before:text-gray-400 before:inline-block before:text-xs before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-3 before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:text-nowrap before:visible before:w-[18px] before:border-separate before:font-fontawesome hover:bg-zinc-900">
                  Status Updates
                </span>
              </label>
            </li>
            <li className="box-border caret-transparent text-nowrap">
              <label className="relative box-border caret-transparent block text-nowrap align-middle">
                <span className="box-border caret-transparent block text-nowrap p-[7.2px] rounded-bl rounded-br rounded-tl rounded-tr before:accent-auto before:caret-transparent before:text-gray-400 before:inline-block before:text-xs before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-3 before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:text-nowrap before:visible before:w-[18px] before:border-separate before:font-fontawesome hover:bg-zinc-900">
                  Topics
                </span>
              </label>
            </li>
            <li className="box-border caret-transparent text-nowrap">
              <label className="relative box-border caret-transparent block text-nowrap align-middle">
                <span className="box-border caret-transparent block text-nowrap p-[7.2px] rounded-bl rounded-br rounded-tl rounded-tr before:accent-auto before:caret-transparent before:text-gray-400 before:inline-block before:text-xs before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-3 before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:text-nowrap before:visible before:w-[18px] before:border-separate before:font-fontawesome hover:bg-zinc-900">
                  Blog Entries
                </span>
              </label>
            </li>
            <li className="box-border caret-transparent text-nowrap">
              <label className="relative box-border caret-transparent block text-nowrap align-middle">
                <span className="box-border caret-transparent block text-nowrap p-[7.2px] rounded-bl rounded-br rounded-tl rounded-tr before:accent-auto before:caret-transparent before:text-gray-400 before:inline-block before:text-xs before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-3 before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:text-nowrap before:visible before:w-[18px] before:border-separate before:font-fontawesome hover:bg-zinc-900">
                  Products
                </span>
              </label>
            </li>
            <li className="box-border caret-transparent text-nowrap">
              <label className="relative box-border caret-transparent block text-nowrap align-middle">
                <span className="box-border caret-transparent block text-nowrap p-[7.2px] rounded-bl rounded-br rounded-tl rounded-tr before:accent-auto before:caret-transparent before:text-gray-400 before:inline-block before:text-xs before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-3 before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:text-nowrap before:visible before:w-[18px] before:border-separate before:font-fontawesome hover:bg-zinc-900">
                  Events
                </span>
              </label>
            </li>
            <li className="box-border caret-transparent text-nowrap">
              <label className="relative box-border caret-transparent block text-nowrap align-middle">
                <span className="box-border caret-transparent block text-nowrap p-[7.2px] rounded-bl rounded-br rounded-tl rounded-tr before:accent-auto before:caret-transparent before:text-gray-400 before:inline-block before:text-xs before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-3 before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:text-nowrap before:visible before:w-[18px] before:border-separate before:font-fontawesome hover:bg-zinc-900">
                  Files
                </span>
              </label>
            </li>
            <li className="box-border caret-transparent text-nowrap">
              <label className="relative box-border caret-transparent block text-nowrap align-middle">
                <span className="box-border caret-transparent block text-nowrap p-[7.2px] rounded-bl rounded-br rounded-tl rounded-tr before:accent-auto before:caret-transparent before:text-gray-400 before:inline-block before:text-xs before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-3 before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:text-nowrap before:visible before:w-[18px] before:border-separate before:font-fontawesome hover:bg-zinc-900">
                  Images
                </span>
              </label>
            </li>
            <li className="box-border caret-transparent text-nowrap">
              <label className="relative box-border caret-transparent block text-nowrap align-middle">
                <span className="box-border caret-transparent block text-nowrap p-[7.2px] rounded-bl rounded-br rounded-tl rounded-tr before:accent-auto before:caret-transparent before:text-gray-400 before:inline-block before:text-xs before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-3 before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:text-nowrap before:visible before:w-[18px] before:border-separate before:font-fontawesome hover:bg-zinc-900">
                  Albums
                </span>
              </label>
            </li>
            <li className="box-border caret-transparent text-nowrap">
              <label className="relative box-border caret-transparent block text-nowrap align-middle">
                <span className="box-border caret-transparent block text-nowrap p-[7.2px] rounded-bl rounded-br rounded-tl rounded-tr before:accent-auto before:caret-transparent before:text-gray-400 before:inline-block before:text-xs before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-3 before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:text-nowrap before:visible before:w-[18px] before:border-separate before:font-fontawesome hover:bg-zinc-900">
                  Pages
                </span>
              </label>
            </li>
            <li className="box-border caret-transparent text-nowrap">
              <label className="relative box-border caret-transparent block text-nowrap align-middle">
                <span className="box-border caret-transparent block text-nowrap p-[7.2px] rounded-bl rounded-br rounded-tl rounded-tr before:accent-auto before:caret-transparent before:text-gray-400 before:inline-block before:text-xs before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-3 before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:text-nowrap before:visible before:w-[18px] before:border-separate before:font-fontawesome hover:bg-zinc-900">
                  Article
                </span>
              </label>
            </li>
            <li className="box-border caret-transparent text-nowrap">
              <label className="relative box-border caret-transparent block text-nowrap align-middle">
                <span className="box-border caret-transparent block text-nowrap p-[7.2px] rounded-bl rounded-br rounded-tl rounded-tr before:accent-auto before:caret-transparent before:text-gray-400 before:inline-block before:text-xs before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-3 before:list-outside before:list-none before:pointer-events-auto before:text-start before:indent-[0px] before:normal-case before:text-nowrap before:visible before:w-[18px] before:border-separate before:font-fontawesome hover:bg-zinc-900">
                  Members
                </span>
              </label>
            </li>
          </ul>
        </details>
      </form>
    </div>
  );
};
