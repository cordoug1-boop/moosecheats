import { HeaderLogo } from "@/sections/Header/components/HeaderLogo";
import { OnlineIndicator } from "@/sections/Header/components/OnlineIndicator";
import { DesktopActions } from "@/sections/Header/components/DesktopActions";
import { MobileCart } from "@/sections/Header/components/MobileCart";

export const TopHeader = () => {
  return (
    <div className="relative box-border caret-transparent h-[100px] z-[11]">
      <div className="relative items-center box-border caret-transparent flex h-full justify-between max-w-[1600px] mx-auto px-[15px]">
        <div className="items-center box-border caret-transparent flex z-10">
          <HeaderLogo />
          <OnlineIndicator />
        </div>
        <DesktopActions />
        <MobileCart />
      </div>
    </div>
  );
};
