export const Hero = () => {
  return (
    <div className="relative bg-[url('https://i.postimg.cc/V6KkrC3z/hero.png')] bg-no-repeat bg-cover box-border caret-transparent mb-[-55px] bg-left mt-0 pt-[65px] pb-[107px] md:mt-[-37px] md:bg-[position:50%_top] md:pt-[118px] md:pb-[120px] after:accent-auto after:bg-[linear-gradient(to_top,rgb(15,16,20),rgba(0,0,0,0))] after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-[100px] after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-disc after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:border-separate after:left-0 after:bottom-0 after:font-inter">
      <div className="relative items-start box-border caret-transparent flex flex-col h-full justify-center max-w-[1600px] mx-auto px-[15px]">
        <h1 className="text-white text-3xl font-black box-border caret-transparent leading-9 text-center mt-[20.1px] mb-[7.5px] mx-auto md:text-[38.4px] md:leading-[46.08px] md:text-start md:mt-[25.728px] md:mb-[9.6px] md:mx-0">
          Elite Game Cheats.
          <br className="text-3xl box-border caret-transparent leading-9 text-center md:text-[38.4px] md:leading-[46.08px] md:text-start" />
          <b className="text-violet-500 text-3xl bg-clip-text bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] box-border caret-transparent leading-9 text-center md:text-[38.4px] md:leading-[46.08px] md:text-start">
            Pro-Level Performance.
          </b>
        </h1>
        <p className="text-[15px] box-border caret-transparent leading-[22.5px] max-w-[600px] text-center md:text-[21px] md:leading-[31.5px] md:text-start">
          Trusted by thousands, Moose Cheats provides high-performance game cheats
          designed for stability and precision. Backed by continuous updates and
          reliable support, we keep you ahead of the competition.
        </p>
        <div className="box-border caret-transparent flex justify-center w-full mt-3.5 mb-2.5 md:block md:justify-normal md:w-auto">
          <a
            href="https://www.trustpilot.com/review/moosecheats.com"
            aria-label="Read our Trustpilot reviews"
            className="text-white text-sm font-medium items-center backdrop-blur-[6px] bg-violet-500/30 shadow-[rgba(0,0,0,0.25)_0px_4px_12px_0px] box-border caret-transparent gap-x-2 flex leading-[18.2px] min-h-[auto] min-w-[auto] gap-y-2 border border-violet-500/40 px-3.5 py-1.5 rounded-xl border-solid md:inline-flex md:min-h-0 md:min-w-0 hover:text-violet-500 hover:bg-violet-500/40"
          >
            <span className="text-emerald-500 font-bold box-border caret-transparent block tracking-[2px] text-nowrap md:text-wrap">
              ★★★★★
            </span>
            <span className="box-border caret-transparent block text-nowrap md:text-wrap">
              Rated{" "}
              <strong className="font-bold box-border caret-transparent text-nowrap md:text-wrap">
                Excellent
              </strong>
              on Trustpilot
            </span>
          </a>
        </div>
        <div className="items-center box-border caret-transparent gap-x-4 block flex-col flex-wrap gap-y-4 mt-4 md:flex md:flex-row md:mt-5">
          <a
            href="/#products"
            className="relative text-zinc-950 text-base font-bold items-center bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] shadow-[rgba(139,96,255,0.25)_0px_2px_10px_0px] box-border caret-transparent gap-x-2 inline-flex justify-center leading-4 max-w-screen-sm min-h-[52px] min-w-0 gap-y-2 uppercase w-full border mt-0 mx-auto px-5 py-[14.4px] rounded-xl border-solid border-transparent md:flex md:max-w-none md:min-h-12 md:min-w-[auto] md:w-auto md:mt-6 md:mx-0 md:px-6 md:py-4 md:rounded-[5px] hover:text-white hover:shadow-[rgba(139,96,255,0.55)_0px_0px_18px_0px,rgba(0,0,0,0.45)_0px_12px_28px_0px] hover:border-violet-500/60"
          >
            <i className="font-black box-border caret-transparent block font-font_awesome_6_pro before:accent-auto before:caret-transparent before:text-zinc-950 before:text-base before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-4 before:list-outside before:list-disc before:pointer-events-auto before:text-start before:indent-[0px] before:uppercase before:visible before:border-separate before:font-font_awesome_6_pro"></i>
            Browse Products
          </a>
          <a
            href="https://discord.gg/gvZtKbsAkR"
            className="relative text-white text-base font-black items-center bg-[linear-gradient(rgb(88,101,242)_0%,rgb(71,82,196)_100%)] shadow-[rgba(0,0,0,0.35)_0px_10px_26px_0px] box-border caret-transparent gap-x-2.5 inline-flex justify-center tracking-[0.4px] leading-4 max-w-screen-sm min-h-[52px] gap-y-2.5 uppercase w-full border border-indigo-500/60 mt-4 mx-auto px-[26px] py-4 rounded-[14px] border-solid md:text-zinc-950 md:font-bold md:bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] md:shadow-[rgba(139,96,255,0.25)_0px_2px_10px_0px] md:gap-x-2 md:hidden md:tracking-[normal] md:max-w-none md:min-h-12 md:gap-y-2 md:w-auto md:mt-6 md:mx-0 md:px-6 md:rounded-[5px] md:border-transparent hover:text-black hover:bg-white hover:shadow-[rgba(139,96,255,0.35)_0px_8px_24px_0px]"
          >
            <i className="text-white bg-no-repeat bg-contain box-border caret-transparent block fill-white tracking-[0.4px] min-h-[auto] min-w-[auto] bg-center font-font_awesome_6_brands md:text-zinc-950 md:inline-block md:fill-black md:tracking-[normal] md:min-h-0 md:min-w-0 before:accent-auto before:caret-transparent before:text-white before:fill-white before:text-base before:not-italic before:normal-nums before:font-normal before:tracking-[0.4px] before:leading-4 before:list-outside before:list-disc before:pointer-events-auto before:text-start before:indent-[0px] before:uppercase before:visible before:border-separate before:font-font_awesome_6_brands before:md:text-zinc-950 before:md:fill-black before:md:tracking-[normal]"></i>
            Join Discord
          </a>
          <a
            href="/files/"
            className="relative text-white/100 text-base font-bold items-center bg-[linear-gradient(to_top,rgba(38,40,51,0.35),rgba(0,0,0,0))] shadow-[rgba(139,96,255,0.35)_0px_0px_8px_0px_inset,rgba(139,96,255,0.25)_0px_0px_6px_0px] box-border caret-transparent gap-x-2 hidden justify-center leading-4 max-w-screen-sm min-h-[52px] min-w-0 gap-y-2 uppercase w-full border border-violet-500 mt-4 mx-auto px-5 py-[14.4px] rounded-xl border-solid md:flex md:max-w-none md:min-h-12 md:min-w-[auto] md:w-auto md:mt-6 md:mx-0 md:px-6 md:py-4 md:rounded-[5px] hover:text-white hover:shadow-[rgba(139,96,255,0.35)_0px_8px_24px_0px]"
          >
            <i className="font-black box-border caret-transparent inline-block min-h-0 min-w-0 font-font_awesome_6_pro md:block md:min-h-[auto] md:min-w-[auto] before:accent-auto before:caret-transparent before:text-white/100 before:text-base before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-4 before:list-outside before:list-disc before:pointer-events-auto before:text-start before:indent-[0px] before:uppercase before:visible before:border-separate before:font-font_awesome_6_pro"></i>
            Installation Guides
          </a>
        </div>
      </div>
    </div>
  );
};
