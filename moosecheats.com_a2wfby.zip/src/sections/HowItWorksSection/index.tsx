export const HowItWorksSection = () => {
  return (
    <section className="relative bg-white/0 shadow-[rgba(0,0,0,0.35)_0px_12px_40px_0px] box-border caret-transparent break-words border overflow-hidden p-[18px] rounded-[18px] border-solid border-white/10 md:break-normal before:accent-auto before:bg-[radial-gradient(700px_220px_at_10%_0%,rgba(139,96,255,0.22),rgba(0,0,0,0)_60%),radial-gradient(700px_220px_at_90%_0%,rgba(139,96,255,0.14),rgba(0,0,0,0)_60%)] before:bg-[position:0%_0%,0%_0%] before:bg-size-[auto,auto] before:caret-transparent before:text-gray-400 before:block before:text-[13px] before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-[20.8px] before:list-outside before:list-none before:break-words before:pointer-events-none before:absolute before:text-start before:indent-[0px] before:normal-case before:visible before:border-separate before:-inset-0.5 before:font-inter before:md:break-normal">
      <header className="relative items-start box-border caret-transparent gap-x-3 flex flex-col justify-between break-words gap-y-3 z-[1] mb-3.5 md:flex-row md:break-normal">
        <div className="box-border caret-transparent break-words md:break-normal">
          <h2 className="text-white/100 text-[22px] font-extrabold box-border caret-transparent tracking-[0.2px] leading-[35.2px] break-words mb-1.5 md:break-normal">
            How it works
          </h2>
          <p className="text-white/70 text-sm box-border caret-transparent leading-[22.4px] max-w-[760px] break-words md:break-normal">
            A quick overview from choosing a product to downloading and getting
            help.
          </p>
        </div>
        <div
          aria-label="Quick links"
          className="box-border caret-transparent gap-x-2 flex flex-wrap break-words gap-y-2 mt-0.5 md:break-normal"
        >
          <a
            href="/how-it-works/"
            className="text-white font-extrabold items-center bg-white/10 shadow-[rgba(139,96,255,0.35)_0px_2px_6px_0px] box-border caret-transparent flex justify-center break-words border px-3 py-2 rounded-[999px] border-solid border-white/10 md:break-normal hover:bg-violet-500/10 hover:shadow-[rgba(139,96,255,0.55)_0px_4px_12px_0px] hover:border-violet-500/40"
          >
            Full guide
          </a>
          <a
            href="/faq/"
            className="text-white font-extrabold items-center bg-white/10 shadow-[rgba(139,96,255,0.35)_0px_2px_6px_0px] box-border caret-transparent flex justify-center break-words border px-3 py-2 rounded-[999px] border-solid border-white/10 md:break-normal hover:bg-violet-500/10 hover:shadow-[rgba(139,96,255,0.55)_0px_4px_12px_0px] hover:border-violet-500/40"
          >
            FAQ
          </a>
          <a
            href="/contact-us/"
            className="text-white font-extrabold items-center bg-violet-500/20 shadow-[rgba(139,96,255,0.35)_0px_2px_6px_0px] box-border caret-transparent flex justify-center break-words border border-violet-500/40 px-3 py-2 rounded-[999px] border-solid md:break-normal hover:bg-violet-500/10 hover:shadow-[rgba(139,96,255,0.55)_0px_4px_12px_0px]"
          >
            Support
          </a>
        </div>
      </header>
      <div className="relative box-border caret-transparent gap-x-3 grid grid-cols-[1fr] break-words gap-y-3 z-[1] md:grid-cols-[repeat(3,minmax(0px,1fr))] md:break-normal">
        <article className="relative bg-black/20 border-l-violet-500/60 box-border caret-transparent break-words pt-3.5 pb-3 px-3.5 rounded-2xl border-l-[3px] border-r-white/10 border-y-white/10 border-b border-r border-t border-solid md:break-normal">
          <div className="items-center box-border caret-transparent gap-x-2.5 flex break-words gap-y-2.5 md:break-normal">
            <span className="text-white/90 text-xs font-black bg-violet-500/10 box-border caret-transparent block shrink-0 tracking-[0.6px] leading-[19.2px] break-words text-nowrap border border-violet-500/20 px-[9px] py-1.5 rounded-[999px] border-solid md:break-normal">
              01
            </span>
            <h3 className="text-white/90 text-[15px] font-extrabold box-border caret-transparent leading-[18px] break-words md:break-normal">
              Choose a product
            </h3>
          </div>
          <p className="text-white/70 box-border caret-transparent break-words mb-3 md:break-normal">
            Browse the marketplace and compare compatibility, access duration,
            and current status before checkout.
          </p>
        </article>
        <article className="relative bg-black/20 border-l-violet-500/60 box-border caret-transparent break-words pt-3.5 pb-3 px-3.5 rounded-2xl border-l-[3px] border-r-white/10 border-y-white/10 border-b border-r border-t border-solid md:break-normal">
          <div className="items-center box-border caret-transparent gap-x-2.5 flex break-words gap-y-2.5 md:break-normal">
            <span className="text-white/90 text-xs font-black bg-violet-500/10 box-border caret-transparent block shrink-0 tracking-[0.6px] leading-[19.2px] break-words text-nowrap border border-violet-500/20 px-[9px] py-1.5 rounded-[999px] border-solid md:break-normal">
              02
            </span>
            <h3 className="text-white/90 text-[15px] font-extrabold box-border caret-transparent leading-[18px] break-words md:break-normal">
              Checkout securely
            </h3>
          </div>
          <p className="text-white/70 box-border caret-transparent break-words mb-3 md:break-normal">
            Payments are processed through trusted providers using encrypted
            connections. We don’t store card details.
          </p>
        </article>
        <article className="relative bg-black/20 border-l-violet-500/60 box-border caret-transparent break-words pt-3.5 pb-3 px-3.5 rounded-2xl border-l-[3px] border-r-white/10 border-y-white/10 border-b border-r border-t border-solid md:break-normal">
          <div className="items-center box-border caret-transparent gap-x-2.5 flex break-words gap-y-2.5 md:break-normal">
            <span className="text-white/90 text-xs font-black bg-violet-500/10 box-border caret-transparent block shrink-0 tracking-[0.6px] leading-[19.2px] break-words text-nowrap border border-violet-500/20 px-[9px] py-1.5 rounded-[999px] border-solid md:break-normal">
              03
            </span>
            <h3 className="text-white/90 text-[15px] font-extrabold box-border caret-transparent leading-[18px] break-words md:break-normal">
              Download + support
            </h3>
          </div>
          <p className="text-white/70 box-border caret-transparent break-words mb-3 md:break-normal">
            After purchase, your account unlocks downloads and setup
            instructions. Support is available if you need help.
          </p>
        </article>
      </div>
      <footer className="relative border-b-gray-400 border-l-gray-400 border-r-gray-400 box-border caret-transparent break-words z-[1] mt-3 pt-3 border-t-white/10 border-t md:break-normal">
        <p className="text-white/70 box-border caret-transparent leading-[22.1px] break-words md:break-normal">
          Want more detail? Read{" "}
          <a
            href="/how-it-works/"
            className="text-violet-500 font-extrabold box-border caret-transparent break-words md:break-normal"
          >
            How It Works
          </a>
          . Common questions are in the{" "}
          <a
            href="/faq/"
            className="text-violet-500 font-extrabold box-border caret-transparent break-words md:break-normal"
          >
            FAQ
          </a>
          . Need help now?{" "}
          <a
            href="/contact-us/"
            className="text-violet-500 font-extrabold box-border caret-transparent break-words md:break-normal"
          >
            Contact support
          </a>
          .
        </p>
      </footer>
    </section>
  );
};
