export const CategoryFilter = () => {
  return (
    <div className="box-border caret-transparent gap-x-[13px] flex overflow-x-scroll overflow-y-auto gap-y-[13px] p-[19.5px]">
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(139,96,255),rgb(81,96,210))] shadow-[rgba(139,96,255,0.5)_0px_0px_3px_0px] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        All Products
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        t
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        h
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        8
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        a
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        b
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        c
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        d
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        e
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        f
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        g
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        m
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        n
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        o
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        p
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        r
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        s
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        v
      </button>
      <button className="text-white text-[11px] font-semibold bg-transparent bg-[linear-gradient(to_right_top,rgb(28,30,37),rgb(28,30,37))] caret-transparent block tracking-[0.5px] leading-[11px] text-center uppercase text-nowrap align-middle px-4 py-3 rounded-[5px]">
        w
      </button>
    </div>
  );
};
