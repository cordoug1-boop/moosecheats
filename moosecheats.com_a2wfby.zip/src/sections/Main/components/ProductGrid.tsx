import { useState } from 'react';
import { ProductDetailModal } from '@/components/ProductDetailModal';

interface PricingOption {
  duration: string;
  price: string;
  priceValue: number;
  popular?: boolean;
}

interface Product {
  id: string;
  name: string;
  image: string;
  description: string;
  price: string;
  features: string[];
  pricingOptions?: PricingOption[];
}

const products: Product[] = [
  {
    id: 'torix-vpn',
    name: 'Torix VPN – Fast & Secure',
    image: 'https://chestercheats.com/uploads/monthly_2026_02/01.png.23ae76bbde89dea97fa6cea6ff6e534b.png',
    description: 'Premium VPN service with military-grade encryption, unlimited bandwidth, and servers worldwide.',
    price: '$9.99',
    pricingOptions: [
      { duration: '1 Week', price: '$4.99', priceValue: 4.99 },
      { duration: '1 Month', price: '$9.99', priceValue: 9.99, popular: true },
      { duration: '3 Months', price: '$24.99', priceValue: 24.99 }
    ],
    features: [
      'Military-grade encryption',
      'Unlimited bandwidth',
      'Global server network',
      'No logs policy',
      '24/7 customer support'
    ]
  },
  {
    id: 'hwid-spoofers',
    name: 'HWID Spoofers',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/HWID.jpg.9330fe6fcd0f43c797ccb853a7464e27.jpg',
    description: 'Advanced hardware ID spoofing to protect your system identity and bypass hardware bans.',
    price: '$19.99',
    pricingOptions: [
      { duration: '1 Day', price: '$9.99', priceValue: 9.99 },
      { duration: '1 Week', price: '$19.99', priceValue: 19.99, popular: true },
      { duration: '1 Month', price: '$49.99', priceValue: 49.99 }
    ],
    features: [
      'Full HWID protection',
      'Bypass hardware bans',
      'Easy one-click setup',
      'Regular updates',
      'Compatible with all major games'
    ]
  },
  {
    id: '8-ball-pool',
    name: '8 Ball Pool Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/8BallPool.jpg.2d1b236ddf96d55abedcd35f9e58fcf9.jpg',
    description: 'Dominate 8 Ball Pool with advanced aiming assistance, extended guidelines, and auto-win features.',
    price: '$14.99',
    pricingOptions: [
      { duration: '1 Day', price: '$4.99', priceValue: 4.99 },
      { duration: '1 Week', price: '$14.99', priceValue: 14.99, popular: true },
      { duration: '1 Month', price: '$39.99', priceValue: 39.99 }
    ],
    features: [
      'Extended aim lines',
      'Auto-win capability',
      'Coin generator',
      'Anti-ban protection',
      'Works on all platforms'
    ]
  },
  {
    id: 'active-matter',
    name: 'Active Matter Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_11/active.png.99b28a3b3bc47ba4e77ed8c037a40604.png',
    description: 'Get the edge in Active Matter with ESP, aimbot, and advanced movement features.',
    price: '$24.99',
    pricingOptions: [
      { duration: '1 Day', price: '$9.99', priceValue: 9.99 },
      { duration: '1 Week', price: '$24.99', priceValue: 24.99, popular: true },
      { duration: '1 Month', price: '$69.99', priceValue: 69.99 }
    ],
    features: [
      'Player ESP',
      'Aimbot with customization',
      'Speed hacks',
      'No recoil',
      'Frequent updates'
    ]
  },
  {
    id: 'apex-legends',
    name: 'Apex Legends Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/ApexLegends.jpg.e26a3da7b3aafa5032a616cad58264c6.jpg',
    description: 'Dominate the arena with advanced ESP, aimbot, and movement enhancements for Apex Legends.',
    price: '$29.99',
    pricingOptions: [
      { duration: '1 Day', price: '$12.99', priceValue: 12.99 },
      { duration: '1 Week', price: '$29.99', priceValue: 29.99, popular: true },
      { duration: '1 Month', price: '$79.99', priceValue: 79.99 }
    ],
    features: [
      'Player & loot ESP',
      'Smooth aimbot',
      'No recoil & spread',
      'Speed boost',
      'Undetected & safe'
    ]
  },
  {
    id: 'arc-raiders',
    name: 'ARC Raiders Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_10/arc-chester.png.c369531438c0a94d77cd728afd05bc37.png',
    description: 'Survive and thrive in ARC Raiders with ESP, aimbot, and resource tracking.',
    price: '$27.99',
    pricingOptions: [
      { duration: '1 Day', price: '$11.99', priceValue: 11.99 },
      { duration: '1 Week', price: '$27.99', priceValue: 27.99, popular: true },
      { duration: '1 Month', price: '$74.99', priceValue: 74.99 }
    ],
    features: [
      'Enemy ESP',
      'Resource ESP',
      'Aimbot',
      'No recoil',
      'Regular updates'
    ]
  },
  {
    id: 'arena-breakout',
    name: 'Arena Breakout Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_11/ABICHESTER.png.7f7d13f76d26df237cb7fca197d98d10.png',
    description: 'Dominate Arena Breakout with advanced ESP, aimbot, and loot detection features.',
    price: '$26.99',
    pricingOptions: [
      { duration: '1 Day', price: '$10.99', priceValue: 10.99 },
      { duration: '1 Week', price: '$26.99', priceValue: 26.99, popular: true },
      { duration: '1 Month', price: '$72.99', priceValue: 72.99 }
    ],
    features: [
      'Player ESP',
      'Loot ESP',
      'Aimbot',
      'No recoil',
      'Anti-ban protection'
    ]
  },
  {
    id: 'ark',
    name: 'ARK Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_09/Ark.png.ee6fb03e0fa33c13e7fffa62e8f2fa89.png',
    description: 'Survive and thrive in ARK with ESP, aimbot, and resource tracking.',
    price: '$22.99',
    pricingOptions: [
      { duration: '1 Day', price: '$8.99', priceValue: 8.99 },
      { duration: '1 Week', price: '$22.99', priceValue: 22.99, popular: true },
      { duration: '1 Month', price: '$62.99', priceValue: 62.99 }
    ],
    features: [
      'Player & dino ESP',
      'Resource ESP',
      'Aimbot',
      'Speed hacks',
      'Frequent updates'
    ]
  },
  {
    id: 'arma-reforger',
    name: 'ARMA Reforger Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2026_02/Arma-Reforger-Cat-Chester.png.3cd4041269f3b5f08387c5ab5aaf89df.png',
    description: 'Tactical advantage in ARMA Reforger with ESP, aimbot, and vehicle tracking.',
    price: '$28.99',
    pricingOptions: [
      { duration: '1 Day', price: '$11.99', priceValue: 11.99 },
      { duration: '1 Week', price: '$28.99', priceValue: 28.99, popular: true },
      { duration: '1 Month', price: '$77.99', priceValue: 77.99 }
    ],
    features: [
      'Player ESP',
      'Vehicle ESP',
      'Aimbot',
      'No recoil',
      'Undetected'
    ]
  },
  {
    id: 'battlefield',
    name: 'Battlefield 6/5/1/2042 Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/Battlefield2042V1.jpg.138312fdf97903d03036ebfc7469fa70.jpg',
    description: 'Dominate Battlefield with advanced ESP, aimbot, and vehicle features.',
    price: '$32.99',
    pricingOptions: [
      { duration: '1 Day', price: '$13.99', priceValue: 13.99 },
      { duration: '1 Week', price: '$32.99', priceValue: 32.99, popular: true },
      { duration: '1 Month', price: '$89.99', priceValue: 89.99 }
    ],
    features: [
      'Player ESP',
      'Vehicle ESP',
      'Aimbot',
      'No recoil & spread',
      'Undetected'
    ]
  },
  {
    id: 'brawlhalla',
    name: 'Brawlhalla Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2026_02/Brawlhalla-Cat-Chester.png.fe66fd70a7fbf32aa552005984d8fb81.png',
    description: 'Get the edge in Brawlhalla with auto-dodge, combo assist, and frame-perfect inputs.',
    price: '$16.99',
    pricingOptions: [
      { duration: '1 Day', price: '$6.99', priceValue: 6.99 },
      { duration: '1 Week', price: '$16.99', priceValue: 16.99, popular: true },
      { duration: '1 Month', price: '$44.99', priceValue: 44.99 }
    ],
    features: [
      'Auto-dodge',
      'Combo assist',
      'Frame-perfect inputs',
      'Anti-ban protection',
      'Regular updates'
    ]
  },
  {
    id: 'call-of-duty',
    name: 'Call Of Duty Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_12/public.png.3b15cd0f1e58ccb4cc83a8226db05c21.png',
    description: 'Dominate Call of Duty with advanced ESP, aimbot, and radar features.',
    price: '$34.99',
    pricingOptions: [
      { duration: '1 Day', price: '$14.99', priceValue: 14.99 },
      { duration: '1 Week', price: '$34.99', priceValue: 34.99, popular: true },
      { duration: '1 Month', price: '$94.99', priceValue: 94.99 }
    ],
    features: [
      'Player ESP',
      'Aimbot',
      'Radar',
      'No recoil',
      'Undetected'
    ]
  },
  {
    id: 'contractors-showdown',
    name: 'Contractors Showdown Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_08/csvr-2.png.db7dee260ca48c6626d54aaaed817fea.png',
    description: 'VR tactical advantage with ESP, aimbot, and weapon tracking.',
    price: '$25.99',
    pricingOptions: [
      { duration: '1 Day', price: '$10.99', priceValue: 10.99 },
      { duration: '1 Week', price: '$25.99', priceValue: 25.99, popular: true },
      { duration: '1 Month', price: '$69.99', priceValue: 69.99 }
    ],
    features: [
      'Player ESP',
      'Weapon ESP',
      'Aimbot',
      'No recoil',
      'VR optimized'
    ]
  },
  {
    id: 'cs2',
    name: 'CS2 Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/CS2.jpg.8d9b455747be1fcfac8ea7993f18983b.jpg',
    description: 'Dominate CS2 with advanced ESP, aimbot, and triggerbot features.',
    price: '$36.99',
    pricingOptions: [
      { duration: '1 Day', price: '$15.99', priceValue: 15.99 },
      { duration: '1 Week', price: '$36.99', priceValue: 36.99, popular: true },
      { duration: '1 Month', price: '$99.99', priceValue: 99.99 }
    ],
    features: [
      'Player ESP',
      'Aimbot',
      'Triggerbot',
      'No recoil',
      'Undetected'
    ]
  },
  {
    id: 'dark-and-darker',
    name: 'Dark and Darker Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/DarkandDarker.jpg.6fca5d72ad78abbb7d84db81ce8f10c7.jpg',
    description: 'Survive the dungeon with ESP, aimbot, and loot tracking.',
    price: '$27.99',
    pricingOptions: [
      { duration: '1 Day', price: '$11.99', priceValue: 11.99 },
      { duration: '1 Week', price: '$27.99', priceValue: 27.99, popular: true },
      { duration: '1 Month', price: '$74.99', priceValue: 74.99 }
    ],
    features: [
      'Player ESP',
      'Loot ESP',
      'Aimbot',
      'Trap detection',
      'Anti-ban protection'
    ]
  },
  {
    id: 'dayz',
    name: 'DayZ Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/DayZ.jpg.40659cc497b16cf2cb1f00b99b2d0e60.jpg',
    description: 'Survive DayZ with ESP, aimbot, and vehicle tracking.',
    price: '$29.99',
    pricingOptions: [
      { duration: '1 Day', price: '$12.99', priceValue: 12.99 },
      { duration: '1 Week', price: '$29.99', priceValue: 29.99, popular: true },
      { duration: '1 Month', price: '$79.99', priceValue: 79.99 }
    ],
    features: [
      'Player ESP',
      'Loot ESP',
      'Vehicle ESP',
      'Aimbot',
      'No recoil'
    ]
  },
  {
    id: 'dead-by-daylight',
    name: 'Dead By Daylight Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/DeadByDaylight.jpg.3dd59da1260df91c25c5840d16859a78.jpg',
    description: 'Dominate as survivor or killer with ESP and advanced features.',
    price: '$18.99',
    pricingOptions: [
      { duration: '1 Day', price: '$7.99', priceValue: 7.99 },
      { duration: '1 Week', price: '$18.99', priceValue: 18.99, popular: true },
      { duration: '1 Month', price: '$49.99', priceValue: 49.99 }
    ],
    features: [
      'Player ESP',
      'Generator ESP',
      'Totem ESP',
      'Speed hacks',
      'Anti-ban protection'
    ]
  },
  {
    id: 'deadside',
    name: 'Deadside Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_11/deadside.png.0084fd7afed069358e3743b5832e0e78.png',
    description: 'Survive Deadside with ESP, aimbot, and loot tracking.',
    price: '$24.99',
    pricingOptions: [
      { duration: '1 Day', price: '$9.99', priceValue: 9.99 },
      { duration: '1 Week', price: '$24.99', priceValue: 24.99, popular: true },
      { duration: '1 Month', price: '$67.99', priceValue: 67.99 }
    ],
    features: [
      'Player ESP',
      'Loot ESP',
      'Aimbot',
      'No recoil',
      'Frequent updates'
    ]
  },
  {
    id: 'delta-force',
    name: 'Delta Force Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/DeltaForce.jpg.5a04366782954619d427a474e1fed6fa.jpg',
    description: 'Tactical advantage in Delta Force with ESP, aimbot, and radar.',
    price: '$31.99',
    pricingOptions: [
      { duration: '1 Day', price: '$13.99', priceValue: 13.99 },
      { duration: '1 Week', price: '$31.99', priceValue: 31.99, popular: true },
      { duration: '1 Month', price: '$86.99', priceValue: 86.99 }
    ],
    features: [
      'Player ESP',
      'Aimbot',
      'Radar',
      'No recoil',
      'Undetected'
    ]
  },
  {
    id: 'dma-cards',
    name: 'DMA Cards & Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_08/DMA.png.3c6b350379b433bb8dd06a585edd136b.png',
    description: 'Hardware-based DMA cards for undetectable cheating across multiple games.',
    price: '$299.99',
    pricingOptions: [
      { duration: 'Hardware Only', price: '$299.99', priceValue: 299.99 },
      { duration: 'Hardware + 1 Month', price: '$349.99', priceValue: 349.99, popular: true },
      { duration: 'Hardware + 3 Months', price: '$449.99', priceValue: 449.99 }
    ],
    features: [
      'Hardware-based cheating',
      'Undetectable by anti-cheat',
      'Works with multiple games',
      'Lifetime hardware warranty',
      'Premium support'
    ]
  },
  {
    id: 'dune-awakening',
    name: 'Dune Awakening Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_11/dune.png.a884f7be20789fa71b83234ad1cce2d6.png',
    description: 'Survive Arrakis with ESP, aimbot, and resource tracking.',
    price: '$26.99',
    pricingOptions: [
      { duration: '1 Day', price: '$10.99', priceValue: 10.99 },
      { duration: '1 Week', price: '$26.99', priceValue: 26.99, popular: true },
      { duration: '1 Month', price: '$72.99', priceValue: 72.99 }
    ],
    features: [
      'Player ESP',
      'Resource ESP',
      'Aimbot',
      'No recoil',
      'Anti-ban protection'
    ]
  },
  {
    id: 'escape-from-tarkov',
    name: 'Escape From Tarkov Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/EscapeFromTarkov.jpg.a5d18e0407b29cae0aee99a899350587.jpg',
    description: 'Dominate Tarkov with advanced ESP, aimbot, and loot tracking.',
    price: '$39.99',
    pricingOptions: [
      { duration: '1 Day', price: '$16.99', priceValue: 16.99 },
      { duration: '1 Week', price: '$39.99', priceValue: 39.99, popular: true },
      { duration: '1 Month', price: '$109.99', priceValue: 109.99 }
    ],
    features: [
      'Player ESP',
      'Loot ESP',
      'Aimbot',
      'No recoil',
      'Undetected'
    ]
  },
  {
    id: 'farlight-84',
    name: 'Farlight 84 Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_11/f84.png.dcb21c04c746f5d47e6e06ae238af15b.png',
    description: 'Dominate Farlight 84 with ESP, aimbot, and vehicle tracking.',
    price: '$21.99',
    pricingOptions: [
      { duration: '1 Day', price: '$8.99', priceValue: 8.99 },
      { duration: '1 Week', price: '$21.99', priceValue: 21.99, popular: true },
      { duration: '1 Month', price: '$59.99', priceValue: 59.99 }
    ],
    features: [
      'Player ESP',
      'Vehicle ESP',
      'Aimbot',
      'No recoil',
      'Anti-ban protection'
    ]
  },
  {
    id: 'fc25',
    name: 'FC25 Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/FC25.jpg.9ccf07941e5159c67bf7e765f8df014b.jpg',
    description: 'Dominate FC25 with auto-aim, skill move assist, and stamina hacks.',
    price: '$19.99',
    pricingOptions: [
      { duration: '1 Day', price: '$7.99', priceValue: 7.99 },
      { duration: '1 Week', price: '$19.99', priceValue: 19.99, popular: true },
      { duration: '1 Month', price: '$54.99', priceValue: 54.99 }
    ],
    features: [
      'Auto-aim',
      'Skill move assist',
      'Stamina hacks',
      'Anti-ban protection',
      'Regular updates'
    ]
  },
  {
    id: 'fc26',
    name: 'FC26 Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_09/FC26.png.99b75318d4b8a62e2d16005b9fe74448.png',
    description: 'Get ahead in FC26 with auto-aim, skill move assist, and stamina hacks.',
    price: '$22.99',
    pricingOptions: [
      { duration: '1 Day', price: '$8.99', priceValue: 8.99 },
      { duration: '1 Week', price: '$22.99', priceValue: 22.99, popular: true },
      { duration: '1 Month', price: '$62.99', priceValue: 62.99 }
    ],
    features: [
      'Auto-aim',
      'Skill move assist',
      'Stamina hacks',
      'Anti-ban protection',
      'Day-one updates'
    ]
  },
  {
    id: 'fortnite',
    name: 'Fortnite Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/Fortnite.jpg.a408a13c829e33070960f60fa97a4fce.jpg',
    description: 'Dominate Fortnite with ESP, aimbot, and building assist.',
    price: '$34.99',
    pricingOptions: [
      { duration: '1 Day', price: '$14.99', priceValue: 14.99 },
      { duration: '1 Week', price: '$34.99', priceValue: 34.99, popular: true },
      { duration: '1 Month', price: '$94.99', priceValue: 94.99 }
    ],
    features: [
      'Player ESP',
      'Aimbot',
      'Building assist',
      'No recoil',
      'Undetected'
    ]
  },
  {
    id: 'gta-fivem',
    name: 'Grand Theft Auto V / FiveM Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/GrandTheftAutoVFiveM.jpg.cff1cc71321c8e541b70a881f6792eda.jpg',
    description: 'Dominate GTA V and FiveM with ESP, aimbot, and vehicle features.',
    price: '$24.99',
    pricingOptions: [
      { duration: '1 Day', price: '$9.99', priceValue: 9.99 },
      { duration: '1 Week', price: '$24.99', priceValue: 24.99, popular: true },
      { duration: '1 Month', price: '$67.99', priceValue: 67.99 }
    ],
    features: [
      'Player ESP',
      'Vehicle ESP',
      'Aimbot',
      'Teleport',
      'Money features'
    ]
  },
  {
    id: 'gray-zone-warfare',
    name: 'Gray Zone Warfare Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/GrayZoneWarfare.jpg.46da8b148a27a9121ee1cd889cdf0542.jpg',
    description: 'Tactical advantage with ESP, aimbot, and loot tracking.',
    price: '$28.99',
    pricingOptions: [
      { duration: '1 Day', price: '$11.99', priceValue: 11.99 },
      { duration: '1 Week', price: '$28.99', priceValue: 28.99, popular: true },
      { duration: '1 Month', price: '$77.99', priceValue: 77.99 }
    ],
    features: [
      'Player ESP',
      'Loot ESP',
      'Aimbot',
      'No recoil',
      'Anti-ban protection'
    ]
  },
  {
    id: 'hell-let-loose',
    name: 'Hell Let Loose Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_11/HLL.png.3764d754736c6d9633f34e68bf7eecc6.png',
    description: 'WWII tactical advantage with ESP, aimbot, and vehicle tracking.',
    price: '$27.99',
    pricingOptions: [
      { duration: '1 Day', price: '$11.99', priceValue: 11.99 },
      { duration: '1 Week', price: '$27.99', priceValue: 27.99, popular: true },
      { duration: '1 Month', price: '$74.99', priceValue: 74.99 }
    ],
    features: [
      'Player ESP',
      'Vehicle ESP',
      'Aimbot',
      'No recoil',
      'Undetected'
    ]
  },
  {
    id: 'highguard',
    name: 'Highguard Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2026_02/Highguard-Cat-Chester.png.3ee580c3a4899d44072c67204eddc4ff.png',
    description: 'Dominate Highguard with ESP, aimbot, and ability tracking.',
    price: '$23.99',
    pricingOptions: [
      { duration: '1 Day', price: '$9.99', priceValue: 9.99 },
      { duration: '1 Week', price: '$23.99', priceValue: 23.99, popular: true },
      { duration: '1 Month', price: '$64.99', priceValue: 64.99 }
    ],
    features: [
      'Player ESP',
      'Ability ESP',
      'Aimbot',
      'No recoil',
      'Anti-ban protection'
    ]
  },
  {
    id: 'humanitz',
    name: 'HumanitZ Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2026_02/05.png.ce976e862b4a45139170519883368d63.png',
    description: 'Survive the zombie apocalypse with ESP, aimbot, and resource tracking.',
    price: '$21.99',
    pricingOptions: [
      { duration: '1 Day', price: '$8.99', priceValue: 8.99 },
      { duration: '1 Week', price: '$21.99', priceValue: 21.99, popular: true },
      { duration: '1 Month', price: '$59.99', priceValue: 59.99 }
    ],
    features: [
      'Player & zombie ESP',
      'Resource ESP',
      'Aimbot',
      'No recoil',
      'Anti-ban protection'
    ]
  },
  {
    id: 'hunt-showdown',
    name: 'Hunt Showdown Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_09/Hunt.png.e0c6e782c7975ebb2dde1a6ff7a782c3.png',
    description: 'Hunt with precision using ESP, aimbot, and boss tracking.',
    price: '$29.99',
    pricingOptions: [
      { duration: '1 Day', price: '$12.99', priceValue: 12.99 },
      { duration: '1 Week', price: '$29.99', priceValue: 29.99, popular: true },
      { duration: '1 Month', price: '$79.99', priceValue: 79.99 }
    ],
    features: [
      'Player ESP',
      'Boss ESP',
      'Aimbot',
      'No recoil',
      'Undetected'
    ]
  },
  {
    id: 'marvel-rivals',
    name: 'Marvel Rivals Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/MarvelRivals.jpg.cf5b34e98f2a307dcfe5a242bf7121a3.jpg',
    description: 'Dominate Marvel Rivals with ESP, aimbot, and ability tracking.',
    price: '$32.99',
    pricingOptions: [
      { duration: '1 Day', price: '$13.99', priceValue: 13.99 },
      { duration: '1 Week', price: '$32.99', priceValue: 32.99, popular: true },
      { duration: '1 Month', price: '$89.99', priceValue: 89.99 }
    ],
    features: [
      'Player ESP',
      'Ability ESP',
      'Aimbot',
      'No recoil',
      'Undetected'
    ]
  },
  {
    id: 'minecraft',
    name: 'Minecraft Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_12/mc-che-cat.webp.2245dc4f3ef025462aa43bbb18e58c0f.webp',
    description: 'Dominate Minecraft with X-Ray, fly, speed, and combat features.',
    price: '$14.99',
    pricingOptions: [
      { duration: '1 Day', price: '$4.99', priceValue: 4.99 },
      { duration: '1 Week', price: '$14.99', priceValue: 14.99, popular: true },
      { duration: '1 Month', price: '$39.99', priceValue: 39.99 }
    ],
    features: [
      'X-Ray vision',
      'Fly & speed hacks',
      'Combat features',
      'Anti-ban protection',
      'Works on all servers'
    ]
  },
  {
    id: 'nba',
    name: 'NBA Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_09/nba.png.848dcd232a4a3822b0640f2601c432d9.png',
    description: 'Dominate NBA games with auto-aim, perfect timing, and stamina hacks.',
    price: '$18.99',
    pricingOptions: [
      { duration: '1 Day', price: '$7.99', priceValue: 7.99 },
      { duration: '1 Week', price: '$18.99', priceValue: 18.99, popular: true },
      { duration: '1 Month', price: '$49.99', priceValue: 49.99 }
    ],
    features: [
      'Auto-aim',
      'Perfect timing',
      'Stamina hacks',
      'Anti-ban protection',
      'Regular updates'
    ]
  },
  {
    id: 'off-the-grid',
    name: 'Off The Grid Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_11/OTG.png.0d0041c6a43d592f47a5addd2222b70b.png',
    description: 'Dominate Off The Grid with ESP, aimbot, and loot tracking.',
    price: '$26.99',
    pricingOptions: [
      { duration: '1 Day', price: '$10.99', priceValue: 10.99 },
      { duration: '1 Week', price: '$26.99', priceValue: 26.99, popular: true },
      { duration: '1 Month', price: '$72.99', priceValue: 72.99 }
    ],
    features: [
      'Player ESP',
      'Loot ESP',
      'Aimbot',
      'No recoil',
      'Anti-ban protection'
    ]
  },
  {
    id: 'overwatch-2',
    name: 'Overwatch 2 Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/Overwatch2.jpg.8ddcfc390b2395d50c58a8dde63f434c.jpg',
    description: 'Dominate Overwatch 2 with ESP, aimbot, and ability tracking.',
    price: '$31.99',
    pricingOptions: [
      { duration: '1 Day', price: '$13.99', priceValue: 13.99 },
      { duration: '1 Week', price: '$31.99', priceValue: 31.99, popular: true },
      { duration: '1 Month', price: '$86.99', priceValue: 86.99 }
    ],
    features: [
      'Player ESP',
      'Ability ESP',
      'Aimbot',
      'No recoil',
      'Undetected'
    ]
  },
  {
    id: 'palworld',
    name: 'Palworld Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_09/Pal-chester.png.1f57bc6632d2b81902119a19e83773e6.png',
    description: 'Dominate Palworld with ESP, aimbot, and pal tracking.',
    price: '$22.99',
    pricingOptions: [
      { duration: '1 Day', price: '$8.99', priceValue: 8.99 },
      { duration: '1 Week', price: '$22.99', priceValue: 22.99, popular: true },
      { duration: '1 Month', price: '$62.99', priceValue: 62.99 }
    ],
    features: [
      'Player & pal ESP',
      'Resource ESP',
      'Aimbot',
      'No recoil',
      'Anti-ban protection'
    ]
  },
  {
    id: 'pioner',
    name: 'Pioner Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2026_02/Pioner-Cat-Chester.png.506e76d3f31d27af37eee5f5cb726d76.png',
    description: 'Survive Pioner with ESP, aimbot, and anomaly detection.',
    price: '$25.99',
    pricingOptions: [
      { duration: '1 Day', price: '$10.99', priceValue: 10.99 },
      { duration: '1 Week', price: '$25.99', priceValue: 25.99, popular: true },
      { duration: '1 Month', price: '$69.99', priceValue: 69.99 }
    ],
    features: [
      'Player ESP',
      'Anomaly ESP',
      'Aimbot',
      'No recoil',
      'Anti-ban protection'
    ]
  },
  {
    id: 'pubg',
    name: 'PUBG Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/PUBG.jpg.5a7b2820e966f882e5e2fd52b9260ce2.jpg',
    description: 'Dominate PUBG with ESP, aimbot, and vehicle tracking.',
    price: '$29.99',
    pricingOptions: [
      { duration: '1 Day', price: '$12.99', priceValue: 12.99 },
      { duration: '1 Week', price: '$29.99', priceValue: 29.99, popular: true },
      { duration: '1 Month', price: '$79.99', priceValue: 79.99 }
    ],
    features: [
      'Player ESP',
      'Vehicle ESP',
      'Aimbot',
      'No recoil',
      'Undetected'
    ]
  },
  {
    id: 'rainbow-6',
    name: 'Rainbow 6 Siege/X Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_10/Rainbow6SiegeX.jpg.08eea526b63c0abff5e58f93346f7a74.jpg',
    description: 'Tactical advantage in Rainbow 6 with ESP, aimbot, and gadget tracking.',
    price: '$33.99',
    pricingOptions: [
      { duration: '1 Day', price: '$14.99', priceValue: 14.99 },
      { duration: '1 Week', price: '$33.99', priceValue: 33.99, popular: true },
      { duration: '1 Month', price: '$92.99', priceValue: 92.99 }
    ],
    features: [
      'Player ESP',
      'Gadget ESP',
      'Aimbot',
      'No recoil',
      'Undetected'
    ]
  },
  {
    id: 'rematch',
    name: 'Rematch Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_08/Rematch-02.webp.b92847ef7ee29e4ce634e489b4bdcd9e.webp',
    description: 'Dominate Rematch with ESP, aimbot, and ability tracking.',
    price: '$24.99',
    pricingOptions: [
      { duration: '1 Day', price: '$9.99', priceValue: 9.99 },
      { duration: '1 Week', price: '$24.99', priceValue: 24.99, popular: true },
      { duration: '1 Month', price: '$67.99', priceValue: 67.99 }
    ],
    features: [
      'Player ESP',
      'Ability ESP',
      'Aimbot',
      'No recoil',
      'Anti-ban protection'
    ]
  },
  {
    id: 'roblox',
    name: 'Roblox Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_08/Roblox.png.8d456b7f51561ca83615a406becd4243.png',
    description: 'Dominate Roblox games with ESP, aimbot, and speed hacks.',
    price: '$12.99',
    pricingOptions: [
      { duration: '1 Day', price: '$3.99', priceValue: 3.99 },
      { duration: '1 Week', price: '$12.99', priceValue: 12.99, popular: true },
      { duration: '1 Month', price: '$34.99', priceValue: 34.99 }
    ],
    features: [
      'Universal ESP',
      'Aimbot',
      'Speed hacks',
      'Anti-ban protection',
      'Works on all games'
    ]
  },
  {
    id: 'rocket-league',
    name: 'Rocket League Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/RocketLeague.jpg.329763a94bb610cf6cde79b688651459.jpg',
    description: 'Dominate Rocket League with ball prediction, auto-aerial, and boost hacks.',
    price: '$17.99',
    pricingOptions: [
      { duration: '1 Day', price: '$6.99', priceValue: 6.99 },
      { duration: '1 Week', price: '$17.99', priceValue: 17.99, popular: true },
      { duration: '1 Month', price: '$47.99', priceValue: 47.99 }
    ],
    features: [
      'Ball prediction',
      'Auto-aerial',
      'Boost hacks',
      'Anti-ban protection',
      'Regular updates'
    ]
  },
  {
    id: 'rogue-company',
    name: 'Rogue Company Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/RogueCompany.jpg.e1b548e568e06b6d434910ad6dd8765b.jpg',
    description: 'Dominate Rogue Company with ESP, aimbot, and ability tracking.',
    price: '$23.99',
    pricingOptions: [
      { duration: '1 Day', price: '$9.99', priceValue: 9.99 },
      { duration: '1 Week', price: '$23.99', priceValue: 23.99, popular: true },
      { duration: '1 Month', price: '$64.99', priceValue: 64.99 }
    ],
    features: [
      'Player ESP',
      'Ability ESP',
      'Aimbot',
      'No recoil',
      'Anti-ban protection'
    ]
  },
  {
    id: 'rust',
    name: 'Rust Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/Rust.jpg.cf360e897ef1c06b3073702109a0a771.jpg',
    description: 'Dominate Rust with ESP, aimbot, and raid assistance.',
    price: '$34.99',
    pricingOptions: [
      { duration: '1 Day', price: '$14.99', priceValue: 14.99 },
      { duration: '1 Week', price: '$34.99', priceValue: 34.99, popular: true },
      { duration: '1 Month', price: '$94.99', priceValue: 94.99 }
    ],
    features: [
      'Player ESP',
      'Resource ESP',
      'Aimbot',
      'Raid assistance',
      'Undetected'
    ]
  },
  {
    id: 'scum',
    name: 'Scum Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/Scum.jpg.0b54d61179287b2e6556a0fe2a408cb0.jpg',
    description: 'Survive SCUM with ESP, aimbot, and loot tracking.',
    price: '$26.99',
    pricingOptions: [
      { duration: '1 Day', price: '$10.99', priceValue: 10.99 },
      { duration: '1 Week', price: '$26.99', priceValue: 26.99, popular: true },
      { duration: '1 Month', price: '$72.99', priceValue: 72.99 }
    ],
    features: [
      'Player ESP',
      'Loot ESP',
      'Aimbot',
      'No recoil',
      'Anti-ban protection'
    ]
  },
  {
    id: 'sea-of-thieves',
    name: 'Sea Of Thieves Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_10/SOT.png.671be6fcd5c7f68b0e864ebed65eb896.png',
    description: 'Dominate the seas with ESP, aimbot, and treasure tracking.',
    price: '$21.99',
    pricingOptions: [
      { duration: '1 Day', price: '$8.99', priceValue: 8.99 },
      { duration: '1 Week', price: '$21.99', priceValue: 21.99, popular: true },
      { duration: '1 Month', price: '$59.99', priceValue: 59.99 }
    ],
    features: [
      'Player & ship ESP',
      'Treasure ESP',
      'Aimbot',
      'No recoil',
      'Anti-ban protection'
    ]
  },
  {
    id: 'squad',
    name: 'Squad Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/Squad.jpg.6859622fdaf67a1eaddc681dfb8ede31.jpg',
    description: 'Tactical advantage in Squad with ESP, aimbot, and vehicle tracking.',
    price: '$28.99',
    pricingOptions: [
      { duration: '1 Day', price: '$11.99', priceValue: 11.99 },
      { duration: '1 Week', price: '$28.99', priceValue: 28.99, popular: true },
      { duration: '1 Month', price: '$77.99', priceValue: 77.99 }
    ],
    features: [
      'Player ESP',
      'Vehicle ESP',
      'Aimbot',
      'No recoil',
      'Undetected'
    ]
  },
  {
    id: 'steam-accounts',
    name: 'Steam Accounts',
    image: 'https://chestercheats.com/uploads/monthly_2025_08/Steam-Accounts-chester.png.e862685a317b323685e02e7994b5fda8.png',
    description: 'Premium Steam accounts with various games and levels.',
    price: '$49.99',
    pricingOptions: [
      { duration: 'Basic Account', price: '$49.99', priceValue: 49.99 },
      { duration: 'Premium Account', price: '$99.99', priceValue: 99.99, popular: true },
      { duration: 'Elite Account', price: '$199.99', priceValue: 199.99 }
    ],
    features: [
      'Verified accounts',
      'Various game libraries',
      'Different Steam levels',
      'Instant delivery',
      'Lifetime warranty'
    ]
  },
  {
    id: 'division-2',
    name: 'The Division 2 Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2026_01/Division-2-Chester.png.a14c34e7df5ce0ea684067f8d130f691.png',
    description: 'Dominate The Division 2 with ESP, aimbot, and loot tracking.',
    price: '$27.99',
    pricingOptions: [
      { duration: '1 Day', price: '$11.99', priceValue: 11.99 },
      { duration: '1 Week', price: '$27.99', priceValue: 27.99, popular: true },
      { duration: '1 Month', price: '$74.99', priceValue: 74.99 }
    ],
    features: [
      'Player ESP',
      'Loot ESP',
      'Aimbot',
      'No recoil',
      'Anti-ban protection'
    ]
  },
  {
    id: 'first-descendant',
    name: 'The First Descendant Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2026_02/03.png.8720e17a649b405da009ade6c10a58c7.png',
    description: 'Dominate The First Descendant with ESP, aimbot, and ability tracking.',
    price: '$29.99',
    pricingOptions: [
      { duration: '1 Day', price: '$12.99', priceValue: 12.99 },
      { duration: '1 Week', price: '$29.99', priceValue: 29.99, popular: true },
      { duration: '1 Month', price: '$79.99', priceValue: 79.99 }
    ],
    features: [
      'Player ESP',
      'Ability ESP',
      'Aimbot',
      'No recoil',
      'Undetected'
    ]
  },
  {
    id: 'midnight-walkers',
    name: 'The Midnight Walkers Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2026_02/TMW-Cat-Chester.png.93b5fcc82dc288a70dc3be33362de34f.png',
    description: 'Survive The Midnight Walkers with ESP, aimbot, and entity tracking.',
    price: '$23.99',
    pricingOptions: [
      { duration: '1 Day', price: '$9.99', priceValue: 9.99 },
      { duration: '1 Week', price: '$23.99', priceValue: 23.99, popular: true },
      { duration: '1 Month', price: '$64.99', priceValue: 64.99 }
    ],
    features: [
      'Player & entity ESP',
      'Resource ESP',
      'Aimbot',
      'No recoil',
      'Anti-ban protection'
    ]
  },
  {
    id: 'the-finals',
    name: 'The Finals Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/TheFinals.jpg.886783db6cba7c5343d1687748470d93.jpg',
    description: 'Dominate The Finals with ESP, aimbot, and destruction tracking.',
    price: '$31.99',
    pricingOptions: [
      { duration: '1 Day', price: '$13.99', priceValue: 13.99 },
      { duration: '1 Week', price: '$31.99', priceValue: 31.99, popular: true },
      { duration: '1 Month', price: '$86.99', priceValue: 86.99 }
    ],
    features: [
      'Player ESP',
      'Destruction ESP',
      'Aimbot',
      'No recoil',
      'Undetected'
    ]
  },
  {
    id: 'valorant',
    name: 'Valorant Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/Valorant.jpg.9a1be9facab701a90a79b11b7d229a6d.jpg',
    description: 'Dominate Valorant with ESP, aimbot, and ability tracking.',
    price: '$36.99',
    pricingOptions: [
      { duration: '1 Day', price: '$15.99', priceValue: 15.99 },
      { duration: '1 Week', price: '$36.99', priceValue: 36.99, popular: true },
      { duration: '1 Month', price: '$99.99', priceValue: 99.99 }
    ],
    features: [
      'Player ESP',
      'Ability ESP',
      'Aimbot',
      'No recoil',
      'Undetected'
    ]
  },
  {
    id: 'war-thunder',
    name: 'War Thunder Cheats',
    image: 'https://chestercheats.com/uploads/monthly_2025_07/WarThunder.jpg.a0bc89fe4189a1dded6aec61c155b4ca.jpg',
    description: 'Dominate War Thunder with ESP, aimbot, and vehicle tracking.',
    price: '$24.99',
    pricingOptions: [
      { duration: '1 Day', price: '$9.99', priceValue: 9.99 },
      { duration: '1 Week', price: '$24.99', priceValue: 24.99, popular: true },
      { duration: '1 Month', price: '$67.99', priceValue: 67.99 }
    ],
    features: [
      'Vehicle ESP',
      'Aimbot',
      'Lead indicator',
      'No recoil',
      'Anti-ban protection'
    ]
  }
];

const productCards = products.map((product, index) => ({
  name: product.name,
  image: product.image,
  index: index
}));

export const ProductGrid = () => {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setTimeout(() => setSelectedProduct(null), 300);
  };

  return (
    <>
      <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
        {productCards.map((card, idx) => (
          <li key={idx} className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
            <button
              onClick={() => handleProductClick(products[card.index])}
              className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500 cursor-pointer bg-transparent border-none p-0"
            >
              <div className={`relative aspect-[365_/_150] bg-[url('${card.image}')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]`}></div>
              <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                {card.name}
              </h2>
            </button>
          </li>
        ))}
      </ul>

      {selectedProduct && (
        <ProductDetailModal
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          product={selectedProduct}
        />
      )}
    </>
  );
};
