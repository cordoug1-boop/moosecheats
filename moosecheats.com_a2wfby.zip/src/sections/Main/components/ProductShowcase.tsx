import { CategoryFilter } from "@/sections/Main/components/CategoryFilter";
import { ProductGrid } from "@/sections/Main/components/ProductGrid";

export const ProductShowcase = () => {
  return (
    <div className="box-border caret-transparent">
      <div className="box-border caret-transparent h-full min-h-[350px] align-top w-full p-2.5 md:p-0">
        <div className="box-border caret-transparent mb-5">
          <ul className="box-border caret-transparent list-none pl-0">
            <li className="relative box-border caret-transparent block mb-2.5 rounded-[5px]">
              <div className="box-border caret-transparent leading-[20.8px] break-words md:break-normal">
                <section className="box-border caret-transparent break-words text-center pt-10 pb-4 px-5 md:break-normal">
                  <div className="box-border caret-transparent max-w-[1100px] break-words mx-auto md:break-normal">
                    <span className="text-white/40 text-[10px] box-border caret-transparent block tracking-[4px] leading-4 break-words uppercase mb-3.5 md:break-normal">
                      Optimized for Performance. Designed for Security.
                    </span>
                    <a
                      href="https://torixvpn.mysellauth.com/"
                      className="text-white shadow-[rgba(0,0,0,0.35)_0px_6px_18px_0px] box-border caret-transparent inline-block break-words underline border border-red-600/30 overflow-hidden border-solid md:break-normal hover:text-violet-500"
                    >
                      <img
                        alt="Trixxware Signature"
                        src="https://c.animaapp.com/mm8t9gj9JSNds2/assets/Torix-VPN-Signature.gif"
                        className="box-border caret-transparent max-h-[90px] max-w-full break-words md:break-normal"
                      />
                    </a>
                  </div>
                </section>
              </div>
            </li>
          </ul>
        </div>
        <div className="relative bg-zinc-900 shadow-[rgba(20,22,27,0.1)_0px_2px_4px_-1px] box-border caret-transparent mb-[26px] rounded-[5px]">
          <CategoryFilter />
          <div className="box-border caret-transparent">
            <div className="box-border caret-transparent">
              <ProductGrid />
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]"></ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/65-torix-vpn-–-fast-secure/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2026_02/01.png.23ae76bbde89dea97fa6cea6ff6e534b.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Torix VPN – Fast &amp; Secure
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="/dma/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2026_01/Division-2-Chester.png.a14c34e7df5ce0ea684067f8d130f691.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      The Division 2 Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/67-the-first-descendant-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2026_02/03.png.8720e17a649b405da009ade6c10a58c7.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      The First Descendant Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/61-the-midnight-walkers-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2026_02/TMW-Cat-Chester.png.93b5fcc82dc288a70dc3be33362de34f.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      The Midnight Walkers Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/30-the-finals-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/TheFinals.jpg.886783db6cba7c5343d1687748470d93.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      The Finals Cheats
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/18-hwid-spoofers/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/HWID.jpg.9330fe6fcd0f43c797ccb853a7464e27.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      HWID Spoofers
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/55-hell-let-loose-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_11/HLL.png.3764d754736c6d9633f34e68bf7eecc6.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Hell Let Loose Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/60-highguard-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2026_02/Highguard-Cat-Chester.png.3ee580c3a4899d44072c67204eddc4ff.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Highguard Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/66-humanitz-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2026_02/05.png.ce976e862b4a45139170519883368d63.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      HumanitZ Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/46-hunt-showdown-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_09/Hunt.png.e0c6e782c7975ebb2dde1a6ff7a782c3.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Hunt Showdown Cheats
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/1-8-ball-pool-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/8BallPool.jpg.2d1b236ddf96d55abedcd35f9e58fcf9.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      8 Ball Pool Cheats
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/51-active-matter-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_11/active.png.99b28a3b3bc47ba4e77ed8c037a40604.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Active Matter Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/33-apex-legends-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/ApexLegends.jpg.e26a3da7b3aafa5032a616cad58264c6.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Apex Legends Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/48-arc-raiders-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_10/arc-chester.png.c369531438c0a94d77cd728afd05bc37.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      ARC Raiders Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/56-arena-breakout-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_11/ABICHESTER.png.7f7d13f76d26df237cb7fca197d98d10.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Arena Breakout Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/45-ark-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_09/Ark.png.ee6fb03e0fa33c13e7fffa62e8f2fa89.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      ARK Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/64-arma-reforger-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2026_02/Arma-Reforger-Cat-Chester.png.3cd4041269f3b5f08387c5ab5aaf89df.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      ARMA Reforger Cheats
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/34-battlefield-6512042-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/Battlefield2042V1.jpg.138312fdf97903d03036ebfc7469fa70.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Battlefield 6/5/1/2042 Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/63-brawlhalla-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2026_02/Brawlhalla-Cat-Chester.png.fe66fd70a7fbf32aa552005984d8fb81.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Brawlhalla Cheats
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/57-call-of-duty-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_12/public.png.3b15cd0f1e58ccb4cc83a8226db05c21.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Call Of Duty Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/38-contractors-showdown-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_08/csvr-2.png.db7dee260ca48c6626d54aaaed817fea.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Contractors Showdown Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/6-cs2-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/CS2.jpg.8d9b455747be1fcfac8ea7993f18983b.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      CS2 Cheats
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/7-dark-and-darker-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/DarkandDarker.jpg.6fca5d72ad78abbb7d84db81ce8f10c7.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Dark and Darker Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/8-dayz-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/DayZ.jpg.40659cc497b16cf2cb1f00b99b2d0e60.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      DayZ Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/9-dead-by-daylight-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/DeadByDaylight.jpg.3dd59da1260df91c25c5840d16859a78.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Dead By Daylight Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/53-deadside-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_11/deadside.png.0084fd7afed069358e3743b5832e0e78.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Deadside Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/10-delta-force-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/DeltaForce.jpg.5a04366782954619d427a474e1fed6fa.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Delta Force Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/39-dma-cards-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_08/DMA.png.3c6b350379b433bb8dd06a585edd136b.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      DMA Cards &amp; Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/50-dune-awakening-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_11/dune.png.a884f7be20789fa71b83234ad1cce2d6.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Dune Awakening Cheats
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/12-escape-from-tarkov-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/EscapeFromTarkov.jpg.a5d18e0407b29cae0aee99a899350587.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Escape From Tarkov Cheats
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/52-farlight-84-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_11/f84.png.dcb21c04c746f5d47e6e06ae238af15b.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Farlight 84 Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/36-fc25-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/FC25.jpg.9ccf07941e5159c67bf7e765f8df014b.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      FC25 Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/44-fc26-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_09/FC26.png.99b75318d4b8a62e2d16005b9fe74448.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      FC26 Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/14-fortnite-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/Fortnite.jpg.a408a13c829e33070960f60fa97a4fce.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Fortnite Cheats
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/16-grand-theft-auto-v-fivem-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/GrandTheftAutoVFiveM.jpg.cff1cc71321c8e541b70a881f6792eda.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Grand Theft Auto V / FiveM Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/17-gray-zone-warfare-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/GrayZoneWarfare.jpg.46da8b148a27a9121ee1cd889cdf0542.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Gray Zone Warfare Cheats
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/19-marvel-rivals-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/MarvelRivals.jpg.cf5b34e98f2a307dcfe5a242bf7121a3.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Marvel Rivals Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/58-minecraft-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_12/mc-che-cat.webp.2245dc4f3ef025462aa43bbb18e58c0f.webp')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Minecraft Cheats
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/43-nba/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_09/nba.png.848dcd232a4a3822b0640f2601c432d9.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      NBA
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/54-off-the-grid-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_11/OTG.png.0d0041c6a43d592f47a5addd2222b70b.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Off The Grid Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/21-overwatch-2-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/Overwatch2.jpg.8ddcfc390b2395d50c58a8dde63f434c.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Overwatch 2 Cheats
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/47-palworld-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_09/Pal-chester.png.1f57bc6632d2b81902119a19e83773e6.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Palworld Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/62-pioner-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2026_02/Pioner-Cat-Chester.png.506e76d3f31d27af37eee5f5cb726d76.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Pioner Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/22-pubg-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/PUBG.jpg.5a7b2820e966f882e5e2fd52b9260ce2.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      PUBG Cheats
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/23-rainbow-6-siegex-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_10/Rainbow6SiegeX.jpg.08eea526b63c0abff5e58f93346f7a74.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Rainbow 6 Siege/X Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/40-rematch-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_08/Rematch-02.webp.b92847ef7ee29e4ce634e489b4bdcd9e.webp')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Rematch Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/42-roblox-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_08/Roblox.png.8d456b7f51561ca83615a406becd4243.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Roblox Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/24-rocket-league-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/RocketLeague.jpg.329763a94bb610cf6cde79b688651459.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Rocket League Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/25-rogue-company-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/RogueCompany.jpg.e1b548e568e06b6d434910ad6dd8765b.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Rogue Company Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/26-rust-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/Rust.jpg.cf360e897ef1c06b3073702109a0a771.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Rust Cheats
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/27-scum-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/Scum.jpg.0b54d61179287b2e6556a0fe2a408cb0.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Scum Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/49-sea-of-thieves-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_10/SOT.png.671be6fcd5c7f68b0e864ebed65eb896.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Sea Of Thieves Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/29-squad-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/Squad.jpg.6859622fdaf67a1eaddc681dfb8ede31.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Squad Cheats
                    </h2>
                  </a>
                </li>
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/37-steam-accounts/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_08/Steam-Accounts-chester.png.e862685a317b323685e02e7994b5fda8.png')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Steam Accounts
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/31-valorant-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/Valorant.jpg.9a1be9facab701a90a79b11b7d229a6d.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      Valorant Cheats
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
            <div className="box-border caret-transparent hidden">
              <ul className="box-border caret-transparent gap-x-[13px] grid grid-cols-[repeat(auto-fill,minmax(315px,1fr))] list-none gap-y-[13px] p-[26px]">
                <li className="relative box-border caret-transparent z-[1] p-0.5 rounded-[5px] after:accent-auto after:bg-slate-800 after:caret-transparent after:text-gray-400 after:block after:text-[13px] after:not-italic after:normal-nums after:font-normal after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:w-full after:z-[-1] after:rounded-[5px] after:border-separate after:left-0 after:top-0 after:font-inter">
                  <a
                    href="https://chestercheats.com/store/category/32-war-thunder-cheats/"
                    className="relative text-white box-border caret-transparent flex h-full min-h-[130px] w-full overflow-hidden rounded-[5px] hover:text-violet-500 hover:border-violet-500"
                  >
                    <div className="relative aspect-[365_/_150] bg-[url('https://chestercheats.com/uploads/monthly_2025_07/WarThunder.jpg.a0bc89fe4189a1dded6aec61c155b4ca.jpg')] bg-cover box-border caret-transparent flex w-full overflow-hidden bg-center rounded-[5px]"></div>
                    <h2 className="absolute font-semibold bg-slate-800 shadow-[rgba(0,0,0,0.2)_0px_0px_5px_0px] box-border caret-transparent leading-[13px] px-[13px] py-[6.5px] rounded-[375px] right-2.5 bottom-2.5 md:rounded-[1280px]">
                      War Thunder Cheats
                    </h2>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <section className="box-border caret-transparent mt-[26px]"></section>
        <div className="box-border caret-transparent mt-2.5">
          <ul className="box-border caret-transparent list-none pl-0">
            <li className="relative box-border caret-transparent block mb-2.5 rounded-[5px]">
              <div className="box-border caret-transparent leading-[20.8px] break-words p-2 md:break-normal md:p-5">
                <section
                  aria-label="Chester Cheats homepage highlights"
                  className="box-border caret-transparent break-words mt-[26px] mx-auto md:break-normal"
                >
                  <div className="box-border caret-transparent gap-x-[18px] grid max-w-[1120px] break-words gap-y-[18px] mx-auto px-4 md:break-normal">
                    <section className="relative bg-white/0 shadow-[rgba(0,0,0,0.35)_0px_12px_40px_0px] box-border caret-transparent break-words border overflow-hidden p-[18px] rounded-[18px] border-solid border-white/10 md:break-normal before:accent-auto before:bg-[radial-gradient(700px_220px_at_10%_0%,rgba(139,96,255,0.22),rgba(0,0,0,0)_60%),radial-gradient(700px_220px_at_90%_0%,rgba(139,96,255,0.14),rgba(0,0,0,0)_60%)] before:bg-[position:0%_0%,0%_0%] before:bg-size-[auto,auto] before:caret-transparent before:text-gray-400 before:block before:text-[13px] before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-[20.8px] before:list-outside before:list-none before:break-words before:pointer-events-none before:absolute before:text-start before:indent-[0px] before:normal-case before:visible before:border-separate before:-inset-0.5 before:font-inter before:md:break-normal">
                      <header className="relative items-start box-border caret-transparent gap-x-3 flex flex-col justify-between break-words gap-y-3 z-[1] mb-3.5 md:flex-row md:break-normal">
                        <div className="box-border caret-transparent break-words md:break-normal">
                          <h2 className="text-white/100 text-[22px] font-extrabold box-border caret-transparent tracking-[0.2px] leading-[35.2px] break-words mb-1.5 md:break-normal">
                            Trusted by the community
                          </h2>
                          <p className="text-white/70 text-sm box-border caret-transparent leading-[22.4px] max-w-[760px] break-words md:break-normal">
                            Read independent feedback, browse community reviews,
                            or reach support fast through official channels.
                          </p>
                        </div>
                        <div
                          aria-label="Trustpilot rating note"
                          className="text-white/90 items-center bg-violet-500/10 box-border caret-transparent gap-x-2.5 flex shrink-0 break-words gap-y-2.5 border border-violet-500/20 px-3 py-2.5 rounded-[14px] border-solid md:break-normal"
                        >
                          <span className="text-emerald-400 box-border caret-transparent block tracking-[2px] break-words md:break-normal">
                            ★★★★★
                          </span>
                          <span className="font-bold box-border caret-transparent block break-words md:break-normal">
                            Reviews on Trustpilot
                          </span>
                        </div>
                      </header>
                      <div className="relative box-border caret-transparent gap-x-3 grid grid-cols-[1fr] break-words gap-y-3 z-[1] md:grid-cols-[repeat(3,minmax(0px,1fr))] md:break-normal">
                        <article className="relative bg-black/20 border-l-violet-500/70 box-border caret-transparent break-words pt-3.5 pb-3 px-3.5 rounded-2xl border-l-[3px] border-r-white/10 border-y-white/10 border-b border-r border-t border-solid md:break-normal">
                          <h3 className="text-violet-300 text-[15px] font-extrabold box-border caret-transparent leading-6 break-words mb-2.5 md:break-normal">
                            Independent reviews
                          </h3>
                          <p className="text-white/70 box-border caret-transparent break-words mb-3 md:break-normal">
                            See verified customer reviews on Trustpilot. This is
                            third-party feedback and cannot be edited by us.
                          </p>
                          <a
                            href="https://www.trustpilot.com/review/chestercheats.com"
                            className="text-white/90 font-extrabold items-center bg-white/10 box-border caret-transparent gap-x-2 inline-flex justify-center break-words gap-y-2 border px-3 py-2.5 rounded-xl border-solid border-white/10 md:break-normal hover:text-violet-500 hover:bg-violet-500/10 hover:border-violet-500/40"
                          >
                            View Trustpilot{" "}
                          </a>
                        </article>
                        <article className="relative bg-black/20 border-l-violet-500/70 box-border caret-transparent break-words pt-3.5 pb-3 px-3.5 rounded-2xl border-l-[3px] border-r-white/10 border-y-white/10 border-b border-r border-t border-solid md:break-normal">
                          <h3 className="text-violet-300 text-[15px] font-extrabold box-border caret-transparent leading-6 break-words mb-2.5 md:break-normal">
                            Community feedback
                          </h3>
                          <p className="text-white/70 box-border caret-transparent break-words mb-3 md:break-normal">
                            Read longer forum reviews, discussions, and
                            follow-ups from real customers in our review
                            section.
                          </p>
                          <a
                            href="/forums/forum/2-reviews/"
                            className="text-white/90 font-extrabold items-center bg-white/10 box-border caret-transparent gap-x-2 inline-flex justify-center break-words gap-y-2 border px-3 py-2.5 rounded-xl border-solid border-white/10 md:break-normal hover:text-violet-500 hover:bg-violet-500/10 hover:border-violet-500/40"
                          >
                            Read forum reviews
                          </a>
                        </article>
                        <article className="relative bg-black/20 border-l-violet-500/70 box-border caret-transparent break-words pt-3.5 pb-3 px-3.5 rounded-2xl border-l-[3px] border-r-white/10 border-y-white/10 border-b border-r border-t border-solid md:break-normal">
                          <h3 className="text-violet-300 text-[15px] font-extrabold box-border caret-transparent leading-6 break-words mb-2.5 md:break-normal">
                            Fast support
                          </h3>
                          <p className="text-white/70 box-border caret-transparent break-words mb-3 md:break-normal">
                            Need help with setup or account access? Contact
                            support through the official page for the quickest
                            routing.
                          </p>
                          <a
                            href="/contact-us/"
                            className="text-white/90 font-extrabold items-center bg-violet-500/20 box-border caret-transparent gap-x-2 inline-flex justify-center break-words gap-y-2 border border-violet-500/30 px-3 py-2.5 rounded-xl border-solid md:break-normal hover:text-violet-500 hover:bg-violet-500/10 hover:border-violet-500/40"
                          >
                            Get support
                          </a>
                        </article>
                      </div>
                    </section>
                    <section className="relative bg-white/0 shadow-[rgba(0,0,0,0.35)_0px_12px_40px_0px] box-border caret-transparent break-words border overflow-hidden p-[18px] rounded-[18px] border-solid border-white/10 md:break-normal before:accent-auto before:bg-[radial-gradient(700px_220px_at_10%_0%,rgba(139,96,255,0.22),rgba(0,0,0,0)_60%),radial-gradient(700px_220px_at_90%_0%,rgba(139,96,255,0.14),rgba(0,0,0,0)_60%)] before:bg-[position:0%_0%,0%_0%] before:bg-size-[auto,auto] before:caret-transparent before:text-gray-400 before:block before:text-[13px] before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-[20.8px] before:list-outside before:list-none before:break-words before:pointer-events-none before:absolute before:text-start before:indent-[0px] before:normal-case before:visible before:border-separate before:-inset-0.5 before:font-inter before:md:break-normal">
                      <header className="relative items-start box-border caret-transparent gap-x-3 flex flex-col justify-between break-words gap-y-3 z-[1] mb-3.5 md:flex-row md:break-normal">
                        <div className="box-border caret-transparent break-words md:break-normal">
                          <h2 className="text-white/100 text-[22px] font-extrabold box-border caret-transparent tracking-[0.2px] leading-[35.2px] break-words mb-1.5 md:break-normal">
                            How it works
                          </h2>
                          <p className="text-white/70 text-sm box-border caret-transparent leading-[22.4px] max-w-[760px] break-words md:break-normal">
                            A quick overview from choosing a product to
                            downloading and getting help.
                          </p>
                        </div>
                        <div
                          aria-label="Quick links"
                          className="box-border caret-transparent gap-x-2 flex flex-wrap break-words gap-y-2 mt-0.5 md:break-normal"
                        >
                          <a
                            href="/how-it-works/"
                            className="text-white font-extrabold items-center bg-white/10 shadow-[rgba(139,96,255,0.35)_0px_2px_6px_0px] box-border caret-transparent flex justify-center break-words border px-3 py-2 rounded-[999px] border-solid border-white/10 md:break-normal hover:bg-violet-500/10 hover:shadow-[rgba(139,96,255,0.55)_0px_4px_12px_0px] hover:border-violet-500/40"
                          >
                            Full guide
                          </a>
                          <a
                            href="/faq/"
                            className="text-white font-extrabold items-center bg-white/10 shadow-[rgba(139,96,255,0.35)_0px_2px_6px_0px] box-border caret-transparent flex justify-center break-words border px-3 py-2 rounded-[999px] border-solid border-white/10 md:break-normal hover:bg-violet-500/10 hover:shadow-[rgba(139,96,255,0.55)_0px_4px_12px_0px] hover:border-violet-500/40"
                          >
                            FAQ
                          </a>
                          <a
                            href="/contact-us/"
                            className="text-white font-extrabold items-center bg-violet-500/20 shadow-[rgba(139,96,255,0.35)_0px_2px_6px_0px] box-border caret-transparent flex justify-center break-words border border-violet-500/40 px-3 py-2 rounded-[999px] border-solid md:break-normal hover:bg-violet-500/10 hover:shadow-[rgba(139,96,255,0.55)_0px_4px_12px_0px]"
                          >
                            Support
                          </a>
                        </div>
                      </header>
                      <div className="relative box-border caret-transparent gap-x-3 grid grid-cols-[1fr] break-words gap-y-3 z-[1] md:grid-cols-[repeat(3,minmax(0px,1fr))] md:break-normal">
                        <article className="relative bg-black/20 border-l-violet-500/60 box-border caret-transparent break-words pt-3.5 pb-3 px-3.5 rounded-2xl border-l-[3px] border-r-white/10 border-y-white/10 border-b border-r border-t border-solid md:break-normal">
                          <div className="items-center box-border caret-transparent gap-x-2.5 flex break-words gap-y-2.5 md:break-normal">
                            <span className="text-white/90 text-xs font-black bg-violet-500/10 box-border caret-transparent block shrink-0 tracking-[0.6px] leading-[19.2px] break-words text-nowrap border border-violet-500/20 px-[9px] py-1.5 rounded-[999px] border-solid md:break-normal">
                              01
                            </span>
                            <h3 className="text-white/90 text-[15px] font-extrabold box-border caret-transparent leading-[18px] break-words md:break-normal">
                              Choose a product
                            </h3>
                          </div>
                          <p className="text-white/70 box-border caret-transparent break-words mb-3 md:break-normal">
                            Browse the marketplace and compare compatibility,
                            access duration, and current status before checkout.
                          </p>
                        </article>
                        <article className="relative bg-black/20 border-l-violet-500/60 box-border caret-transparent break-words pt-3.5 pb-3 px-3.5 rounded-2xl border-l-[3px] border-r-white/10 border-y-white/10 border-b border-r border-t border-solid md:break-normal">
                          <div className="items-center box-border caret-transparent gap-x-2.5 flex break-words gap-y-2.5 md:break-normal">
                            <span className="text-white/90 text-xs font-black bg-violet-500/10 box-border caret-transparent block shrink-0 tracking-[0.6px] leading-[19.2px] break-words text-nowrap border border-violet-500/20 px-[9px] py-1.5 rounded-[999px] border-solid md:break-normal">
                              02
                            </span>
                            <h3 className="text-white/90 text-[15px] font-extrabold box-border caret-transparent leading-[18px] break-words md:break-normal">
                              Checkout securely
                            </h3>
                          </div>
                          <p className="text-white/70 box-border caret-transparent break-words mb-3 md:break-normal">
                            Payments are processed through trusted providers
                            using encrypted connections. We don’t store card
                            details.
                          </p>
                        </article>
                        <article className="relative bg-black/20 border-l-violet-500/60 box-border caret-transparent break-words pt-3.5 pb-3 px-3.5 rounded-2xl border-l-[3px] border-r-white/10 border-y-white/10 border-b border-r border-t border-solid md:break-normal">
                          <div className="items-center box-border caret-transparent gap-x-2.5 flex break-words gap-y-2.5 md:break-normal">
                            <span className="text-white/90 text-xs font-black bg-violet-500/10 box-border caret-transparent block shrink-0 tracking-[0.6px] leading-[19.2px] break-words text-nowrap border border-violet-500/20 px-[9px] py-1.5 rounded-[999px] border-solid md:break-normal">
                              03
                            </span>
                            <h3 className="text-white/90 text-[15px] font-extrabold box-border caret-transparent leading-[18px] break-words md:break-normal">
                              Download + support
                            </h3>
                          </div>
                          <p className="text-white/70 box-border caret-transparent break-words mb-3 md:break-normal">
                            After purchase, your account unlocks downloads and
                            setup instructions. Support is available if you need
                            help.
                          </p>
                        </article>
                      </div>
                      <footer className="relative border-b-gray-400 border-l-gray-400 border-r-gray-400 box-border caret-transparent break-words z-[1] mt-3 pt-3 border-t-white/10 border-t md:break-normal">
                        <p className="text-white/70 box-border caret-transparent leading-[22.1px] break-words md:break-normal">
                          Want more detail? Read{" "}
                          <a
                            href="/how-it-works/"
                            className="text-violet-500 font-extrabold box-border caret-transparent break-words md:break-normal"
                          >
                            How It Works
                          </a>
                          . Common questions are in the{" "}
                          <a
                            href="/faq/"
                            className="text-violet-500 font-extrabold box-border caret-transparent break-words md:break-normal"
                          >
                            FAQ
                          </a>
                          . Need help now?{" "}
                          <a
                            href="/contact-us/"
                            className="text-violet-500 font-extrabold box-border caret-transparent break-words md:break-normal"
                          >
                            Contact support
                          </a>
                          .
                        </p>
                      </footer>
                    </section>
                  </div>
                </section>
              </div>
            </li>
            <li className="relative bg-zinc-900 shadow-[rgba(20,22,27,0.1)_0px_2px_4px_-1px] box-border caret-transparent block mb-2.5 rounded-[5px]">
              <div className="box-border caret-transparent leading-[20.8px] break-words p-2 md:break-normal md:p-5">
                <section className="box-border caret-transparent break-words pt-[72px] pb-[78px] px-[18px] md:break-normal">
                  <div className="box-border caret-transparent max-w-[1180px] break-words mx-auto md:break-normal">
                    <header className="box-border caret-transparent break-words text-center mb-10 md:break-normal">
                      <span className="text-violet-100 text-[12.8px] font-extrabold items-center bg-violet-500/10 box-border caret-transparent gap-x-2 inline-flex tracking-[1.024px] leading-[20.48px] break-words gap-y-2 uppercase border border-violet-500/20 px-3.5 py-1.5 rounded-[999px] border-solid md:break-normal">
                        <i className="font-black box-border caret-transparent block leading-[12.8px] break-words font-font_awesome_6_pro md:break-normal before:accent-auto before:caret-transparent before:text-violet-100 before:text-[12.8px] before:not-italic before:normal-nums before:font-black before:tracking-[1.024px] before:leading-[12.8px] before:list-outside before:list-none before:break-words before:pointer-events-auto before:text-center before:indent-[0px] before:uppercase before:visible before:border-separate before:font-font_awesome_6_pro before:md:break-normal"></i>
                        Why Choose Chester Cheats?
                      </span>
                      <h2 className="text-[30.4px] font-bold box-border caret-transparent leading-[34.96px] break-words mt-4 mb-3 md:text-[41.6px] md:leading-[47.84px] md:break-normal">
                        Safety. Speed. Support.
                      </h2>
                      <p className="text-[16.32px] box-border caret-transparent leading-[26.112px] max-w-[900px] break-words mx-auto md:break-normal">
                        At Chester Cheats, we’re dedicated to building refined,
                        high-performance tools that remain secure and stable.
                        Trusted by a growing global player base, we deliver
                        instant access, secure transactions, and 24/7 guidance —
                        all built on our proven foundation of safety and
                        reliability.
                      </p>
                    </header>
                    <div className="box-border caret-transparent gap-x-[26px] grid grid-cols-[1fr] break-words gap-y-[26px] md:grid-cols-[repeat(4,minmax(0px,1fr))] md:break-normal">
                      <article className="relative shadow-[rgba(0,0,0,0.55)_0px_18px_38px_0px] box-border caret-transparent break-words text-center border overflow-hidden pt-6 pb-[22px] px-[22px] rounded-[18px] border-solid border-white/10 md:break-normal before:accent-auto before:border-b-violet-500/20 before:border-l-gray-400 before:border-r-gray-400 before:border-t-violet-400/70 before:caret-transparent before:text-gray-400 before:block before:text-[13px] before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-[20.8px] before:list-outside before:list-none before:opacity-55 before:break-words before:pointer-events-none before:absolute before:text-center before:indent-[0px] before:normal-case before:visible before:rounded-[18px] before:border-t-2 before:border-b before:border-separate before:inset-0 before:font-inter before:md:break-normal">
                        <div className="text-white text-[22.4px] items-center bg-[linear-gradient(135deg,rgb(179,153,255),rgb(139,96,255))] shadow-[rgba(139,96,255,0.55)_0px_14px_30px_0px] box-border caret-transparent grid h-[60px] justify-items-center leading-[35.84px] break-words w-[60px] mb-3.5 mx-auto rounded-[20px] md:break-normal">
                          <i className="font-black box-border caret-transparent block leading-[22.4px] break-words font-font_awesome_6_pro md:break-normal before:accent-auto before:caret-transparent before:text-white before:text-[22.4px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[22.4px] before:list-outside before:list-none before:break-words before:pointer-events-auto before:text-center before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro before:md:break-normal"></i>
                        </div>
                        <h3 className="text-[17.92px] font-bold box-border caret-transparent leading-[28.672px] break-words my-1.5 md:break-normal">
                          24/7 Support
                        </h3>
                        <p className="text-[15.04px] box-border caret-transparent leading-[24.064px] break-words mb-2.5 md:break-normal">
                          Always here when you need us
                        </p>
                        <p className="text-[15.2px] box-border caret-transparent leading-[24.32px] break-words md:break-normal">
                          Our dedicated support team is online 24/7, every day
                          of the year. Whether it’s installation help, setup
                          guidance, or troubleshooting, you’ll always have an
                          expert ready to assist.
                        </p>
                      </article>
                      <article className="relative shadow-[rgba(0,0,0,0.55)_0px_18px_38px_0px] box-border caret-transparent break-words text-center border overflow-hidden pt-6 pb-[22px] px-[22px] rounded-[18px] border-solid border-white/10 md:break-normal before:accent-auto before:border-b-violet-500/20 before:border-l-gray-400 before:border-r-gray-400 before:border-t-violet-400/70 before:caret-transparent before:text-gray-400 before:block before:text-[13px] before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-[20.8px] before:list-outside before:list-none before:opacity-55 before:break-words before:pointer-events-none before:absolute before:text-center before:indent-[0px] before:normal-case before:visible before:rounded-[18px] before:border-t-2 before:border-b before:border-separate before:inset-0 before:font-inter before:md:break-normal">
                        <div className="text-white text-[22.4px] items-center bg-[linear-gradient(135deg,rgb(179,153,255),rgb(139,96,255))] shadow-[rgba(139,96,255,0.55)_0px_14px_30px_0px] box-border caret-transparent grid h-[60px] justify-items-center leading-[35.84px] break-words w-[60px] mb-3.5 mx-auto rounded-[20px] md:break-normal">
                          <i className="font-black box-border caret-transparent block leading-[22.4px] break-words font-font_awesome_6_pro md:break-normal before:accent-auto before:caret-transparent before:text-white before:text-[22.4px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[22.4px] before:list-outside before:list-none before:break-words before:pointer-events-auto before:text-center before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro before:md:break-normal"></i>
                        </div>
                        <h3 className="text-[17.92px] font-bold box-border caret-transparent leading-[28.672px] break-words my-1.5 md:break-normal">
                          Safety &amp; Quality
                        </h3>
                        <p className="text-[15.04px] box-border caret-transparent leading-[24.064px] break-words mb-2.5 md:break-normal">
                          Account-first design
                        </p>
                        <p className="text-[15.2px] box-border caret-transparent leading-[24.32px] break-words md:break-normal">
                          Each release is validated for clean performance and
                          detection resistance. Our security measures ensure
                          your sessions remain private, protected, and reliable.
                        </p>
                      </article>
                      <article className="relative shadow-[rgba(0,0,0,0.55)_0px_18px_38px_0px] box-border caret-transparent break-words text-center border overflow-hidden pt-6 pb-[22px] px-[22px] rounded-[18px] border-solid border-white/10 md:break-normal before:accent-auto before:border-b-violet-500/20 before:border-l-gray-400 before:border-r-gray-400 before:border-t-violet-400/70 before:caret-transparent before:text-gray-400 before:block before:text-[13px] before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-[20.8px] before:list-outside before:list-none before:opacity-55 before:break-words before:pointer-events-none before:absolute before:text-center before:indent-[0px] before:normal-case before:visible before:rounded-[18px] before:border-t-2 before:border-b before:border-separate before:inset-0 before:font-inter before:md:break-normal">
                        <div className="text-white text-[22.4px] items-center bg-[linear-gradient(135deg,rgb(179,153,255),rgb(139,96,255))] shadow-[rgba(139,96,255,0.55)_0px_14px_30px_0px] box-border caret-transparent grid h-[60px] justify-items-center leading-[35.84px] break-words w-[60px] mb-3.5 mx-auto rounded-[20px] md:break-normal">
                          <i className="font-black box-border caret-transparent block leading-[22.4px] break-words font-font_awesome_6_pro md:break-normal before:accent-auto before:caret-transparent before:text-white before:text-[22.4px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[22.4px] before:list-outside before:list-none before:break-words before:pointer-events-auto before:text-center before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro before:md:break-normal"></i>
                        </div>
                        <h3 className="text-[17.92px] font-bold box-border caret-transparent leading-[28.672px] break-words my-1.5 md:break-normal">
                          Instant Delivery
                        </h3>
                        <p className="text-[15.04px] box-border caret-transparent leading-[24.064px] break-words mb-2.5 md:break-normal">
                          Ready when you are
                        </p>
                        <p className="text-[15.2px] box-border caret-transparent leading-[24.32px] break-words md:break-normal">
                          As soon as your transaction completes, your tools are
                          instantly available. Start playing immediately — no
                          waiting, no delays.
                        </p>
                      </article>
                      <article className="relative shadow-[rgba(0,0,0,0.55)_0px_18px_38px_0px] box-border caret-transparent break-words text-center border overflow-hidden pt-6 pb-[22px] px-[22px] rounded-[18px] border-solid border-white/10 md:break-normal before:accent-auto before:border-b-violet-500/20 before:border-l-gray-400 before:border-r-gray-400 before:border-t-violet-400/70 before:caret-transparent before:text-gray-400 before:block before:text-[13px] before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-[20.8px] before:list-outside before:list-none before:opacity-55 before:break-words before:pointer-events-none before:absolute before:text-center before:indent-[0px] before:normal-case before:visible before:rounded-[18px] before:border-t-2 before:border-b before:border-separate before:inset-0 before:font-inter before:md:break-normal">
                        <div className="text-white text-[22.4px] items-center bg-[linear-gradient(135deg,rgb(179,153,255),rgb(139,96,255))] shadow-[rgba(139,96,255,0.55)_0px_14px_30px_0px] box-border caret-transparent grid h-[60px] justify-items-center leading-[35.84px] break-words w-[60px] mb-3.5 mx-auto rounded-[20px] md:break-normal">
                          <i className="font-black box-border caret-transparent block leading-[22.4px] break-words font-font_awesome_6_pro md:break-normal before:accent-auto before:caret-transparent before:text-white before:text-[22.4px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[22.4px] before:list-outside before:list-none before:break-words before:pointer-events-auto before:text-center before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro before:md:break-normal"></i>
                        </div>
                        <h3 className="text-[17.92px] font-bold box-border caret-transparent leading-[28.672px] break-words my-1.5 md:break-normal">
                          Secure Payments
                        </h3>
                        <p className="text-[15.04px] box-border caret-transparent leading-[24.064px] break-words mb-2.5 md:break-normal">
                          Peace of mind with every purchase
                        </p>
                        <p className="text-[15.2px] box-border caret-transparent leading-[24.32px] break-words md:break-normal">
                          All payments are handled through a robust and
                          encrypted system, ensuring your data and transactions
                          stay protected at every step.
                        </p>
                      </article>
                    </div>
                  </div>
                </section>
              </div>
            </li>
            <li className="relative bg-zinc-900 shadow-[rgba(20,22,27,0.1)_0px_2px_4px_-1px] box-border caret-transparent mb-2.5 rounded-[5px]">
              <h3 className="relative text-base font-bold border-b-zinc-900 border-l-gray-400 border-r-gray-400 border-t-gray-400 box-border caret-transparent leading-4 p-4 rounded-t-[5px] border-b font-inter">
                Member Statistics
              </h3>
              <div className="box-border caret-transparent">
                <div className="items-stretch box-border caret-transparent flex flex-col justify-between p-5 md:items-center md:flex-row">
                  <div className="items-center box-border caret-transparent flex grow justify-around">
                    <div className="box-border caret-transparent text-center">
                      <span className="text-xl font-bold box-border caret-transparent leading-[25px]">
                        1121
                      </span>
                      <br className="box-border caret-transparent" />
                      <span className="box-border caret-transparent leading-[19.89px]">
                        Total Members
                      </span>
                    </div>
                    <div className="box-border caret-transparent text-center">
                      <span
                        title="10/07/25 09:01  AM"
                        className="text-xl font-bold box-border caret-transparent leading-[25px]"
                      >
                        123
                      </span>
                      <br className="box-border caret-transparent" />
                      <span className="box-border caret-transparent leading-[19.89px]">
                        Most Online
                      </span>
                    </div>
                  </div>
                  <div className="border-b-gray-400 border-l-gray-400 border-r-gray-400 border-t-gray-400/20 box-border caret-transparent flex justify-center mr-0 mt-5 pl-0 pt-5 border-l-0 border-t md:border-l-gray-400/20 md:border-t-gray-400 md:block md:justify-normal md:mr-10 md:mt-0 md:pl-5 md:pt-0 md:border-t-0 md:border-l">
                    <div className="box-border caret-transparent min-h-[auto] md:min-h-0">
                      <a
                        href="https://chestercheats.com/profile/1121-llstatic/"
                        title="Go to llStatic's profile"
                        className="relative text-white bg-zinc-900 box-border caret-transparent block float-left h-11 leading-[0px] align-middle w-11 rounded-[500px] after:accent-auto after:caret-transparent after:text-white after:hidden after:text-[13px] after:not-italic after:normal-nums after:font-normal after:tracking-[normal] after:leading-[0px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:border-separate after:font-inter hover:text-violet-500 hover:border-violet-500"
                      >
                        <img
                          src="https://c.animaapp.com/mm8t9gj9JSNds2/assets/image-1.svg"
                          alt="llStatic"
                          className="box-border caret-transparent h-full object-cover align-top w-full rounded-[500px]"
                        />
                      </a>
                      <div className="box-border caret-transparent ml-[55px]">
                        <span className="text-xs box-border caret-transparent leading-[18px] uppercase font-inter">
                          Newest Member
                        </span>
                        <br className="box-border caret-transparent" />
                        <span className="text-[13px] box-border caret-transparent leading-[13px] md:text-sm md:leading-[14px]">
                          <a
                            href="https://chestercheats.com/profile/1121-llstatic/"
                            title="Go to llStatic's profile"
                            className="text-white text-[13px] box-border caret-transparent leading-[13px] break-words md:text-sm md:leading-[14px] hover:text-violet-500 hover:border-violet-500"
                          >
                            llStatic
                          </a>
                        </span>
                        <br className="box-border caret-transparent" />
                        <span className="text-xs box-border caret-transparent leading-[17.4px]">
                          Joined{" "}
                          <time
                            title="03/02/26 06:18  AM"
                            className="box-border caret-transparent"
                          >
                            23 minutes ago
                          </time>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
