import { ProductShowcase } from "@/sections/Main/components/ProductShowcase";

export const Main = () => {
  return (
    <main className="relative box-border caret-transparent max-w-full mx-0 px-0 md:max-w-[1600px] md:mx-auto md:px-[15px]">
      <div className="box-border caret-transparent">
        <ProductShowcase />
      </div>
    </main>
  );
};
