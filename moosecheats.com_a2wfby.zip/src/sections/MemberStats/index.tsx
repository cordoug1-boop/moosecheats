export const MemberStats = () => {
  return (
    <div className="box-border caret-transparent">
      <div className="items-stretch box-border caret-transparent flex flex-col justify-between p-5 md:items-center md:flex-row">
        <div className="items-center box-border caret-transparent flex grow justify-around">
          <div className="box-border caret-transparent text-center">
            <span className="text-xl font-bold box-border caret-transparent leading-[25px]">
              1121
            </span>
            <br className="box-border caret-transparent" />
            <span className="box-border caret-transparent leading-[19.89px]">
              Total Members
            </span>
          </div>
          <div className="box-border caret-transparent text-center">
            <span
              title="10/07/25 09:01  AM"
              className="text-xl font-bold box-border caret-transparent leading-[25px]"
            >
              123
            </span>
            <br className="box-border caret-transparent" />
            <span className="box-border caret-transparent leading-[19.89px]">
              Most Online
            </span>
          </div>
        </div>
        <div className="border-b-gray-400 border-l-gray-400 border-r-gray-400 border-t-gray-400/20 box-border caret-transparent flex justify-center mr-0 mt-5 pl-0 pt-5 border-l-0 border-t md:border-l-gray-400/20 md:border-t-gray-400 md:block md:justify-normal md:mr-10 md:mt-0 md:pl-5 md:pt-0 md:border-t-0 md:border-l">
          <div className="box-border caret-transparent min-h-[auto] md:min-h-0">
            <a
              href="https://moosecheats.com/profile/1121-llstatic/"
              title="Go to llStatic's profile"
              className="relative text-white bg-zinc-900 box-border caret-transparent block float-left h-11 leading-[0px] align-middle w-11 rounded-[500px] after:accent-auto after:caret-transparent after:text-white after:hidden after:text-[13px] after:not-italic after:normal-nums after:font-normal after:tracking-[normal] after:leading-[0px] after:list-outside after:list-none after:pointer-events-auto after:absolute after:text-start after:indent-[0px] after:normal-case after:visible after:border-separate after:font-inter hover:text-violet-500 hover:border-violet-500"
            >
              <img
                src="https://c.animaapp.com/mm8t9gj9JSNds2/assets/image-1.svg"
                alt="llStatic"
                className="box-border caret-transparent h-full object-cover align-top w-full rounded-[500px]"
              />
            </a>
            <div className="box-border caret-transparent ml-[55px]">
              <span className="text-xs box-border caret-transparent leading-[18px] uppercase font-inter">
                Newest Member
              </span>
              <br className="box-border caret-transparent" />
              <span className="text-[13px] box-border caret-transparent leading-[13px] md:text-sm md:leading-[14px]">
                <a
                  href="https://moosecheats.com/profile/1121-llstatic/"
                  title="Go to llStatic's profile"
                  className="text-white text-[13px] box-border caret-transparent leading-[13px] break-words md:text-sm md:leading-[14px] hover:text-violet-500 hover:border-violet-500"
                >
                  llStatic
                </a>
              </span>
              <br className="box-border caret-transparent" />
              <span className="text-xs box-border caret-transparent leading-[17.4px]">
                Joined{" "}
                <time
                  title="03/02/26 06:18  AM"
                  className="box-border caret-transparent"
                >
                  23 minutes ago
                </time>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
