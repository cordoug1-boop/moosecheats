export const WhyChooseSection = () => {
  return (
    <section className="box-border caret-transparent break-words pt-[72px] pb-[78px] px-[18px] md:break-normal">
      <div className="box-border caret-transparent max-w-[1180px] break-words mx-auto md:break-normal">
        <header className="box-border caret-transparent break-words text-center mb-10 md:break-normal">
          <span className="text-violet-100 text-[12.8px] font-extrabold items-center bg-violet-500/10 box-border caret-transparent gap-x-2 inline-flex tracking-[1.024px] leading-[20.48px] break-words gap-y-2 uppercase border border-violet-500/20 px-3.5 py-1.5 rounded-[999px] border-solid md:break-normal">
            <i className="font-black box-border caret-transparent block leading-[12.8px] break-words font-font_awesome_6_pro md:break-normal before:accent-auto before:caret-transparent before:text-violet-100 before:text-[12.8px] before:not-italic before:normal-nums before:font-black before:tracking-[1.024px] before:leading-[12.8px] before:list-outside before:list-none before:break-words before:pointer-events-auto before:text-center before:indent-[0px] before:uppercase before:visible before:border-separate before:font-font_awesome_6_pro before:md:break-normal"></i>
            Why Choose Moose Cheats?
          </span>
          <h2 className="text-[30.4px] font-bold box-border caret-transparent leading-[34.96px] break-words mt-4 mb-3 md:text-[41.6px] md:leading-[47.84px] md:break-normal">
            Safety. Speed. Support.
          </h2>
          <p className="text-[16.32px] box-border caret-transparent leading-[26.112px] max-w-[900px] break-words mx-auto md:break-normal">
            At Moose Cheats, we're dedicated to building refined,
            high-performance tools that remain secure and stable. Trusted by a
            growing global player base, we deliver instant access, secure
            transactions, and 24/7 guidance — all built on our proven foundation
            of safety and reliability.
          </p>
        </header>
        <div className="box-border caret-transparent gap-x-[26px] grid grid-cols-[1fr] break-words gap-y-[26px] md:grid-cols-[repeat(4,minmax(0px,1fr))] md:break-normal">
          <article className="relative shadow-[rgba(0,0,0,0.55)_0px_18px_38px_0px] box-border caret-transparent break-words text-center border overflow-hidden pt-6 pb-[22px] px-[22px] rounded-[18px] border-solid border-white/10 md:break-normal before:accent-auto before:border-b-violet-500/20 before:border-l-gray-400 before:border-r-gray-400 before:border-t-violet-400/70 before:caret-transparent before:text-gray-400 before:block before:text-[13px] before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-[20.8px] before:list-outside before:list-none before:opacity-55 before:break-words before:pointer-events-none before:absolute before:text-center before:indent-[0px] before:normal-case before:visible before:rounded-[18px] before:border-t-2 before:border-b before:border-separate before:inset-0 before:font-inter before:md:break-normal">
            <div className="text-white text-[22.4px] items-center bg-[linear-gradient(135deg,rgb(179,153,255),rgb(139,96,255))] shadow-[rgba(139,96,255,0.55)_0px_14px_30px_0px] box-border caret-transparent grid h-[60px] justify-items-center leading-[35.84px] break-words w-[60px] mb-3.5 mx-auto rounded-[20px] md:break-normal">
              <i className="font-black box-border caret-transparent block leading-[22.4px] break-words font-font_awesome_6_pro md:break-normal before:accent-auto before:caret-transparent before:text-white before:text-[22.4px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[22.4px] before:list-outside before:list-none before:break-words before:pointer-events-auto before:text-center before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro before:md:break-normal"></i>
            </div>
            <h3 className="text-[17.92px] font-bold box-border caret-transparent leading-[28.672px] break-words my-1.5 md:break-normal">
              24/7 Support
            </h3>
            <p className="text-[15.04px] box-border caret-transparent leading-[24.064px] break-words mb-2.5 md:break-normal">
              Always here when you need us
            </p>
            <p className="text-[15.2px] box-border caret-transparent leading-[24.32px] break-words md:break-normal">
              Our dedicated support team is online 24/7, every day of the year.
              Whether it's installation help, setup guidance, or
              troubleshooting, you'll always have an expert ready to assist.
            </p>
          </article>
          <article className="relative shadow-[rgba(0,0,0,0.55)_0px_18px_38px_0px] box-border caret-transparent break-words text-center border overflow-hidden pt-6 pb-[22px] px-[22px] rounded-[18px] border-solid border-white/10 md:break-normal before:accent-auto before:border-b-violet-500/20 before:border-l-gray-400 before:border-r-gray-400 before:border-t-violet-400/70 before:caret-transparent before:text-gray-400 before:block before:text-[13px] before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-[20.8px] before:list-outside before:list-none before:opacity-55 before:break-words before:pointer-events-none before:absolute before:text-center before:indent-[0px] before:normal-case before:visible before:rounded-[18px] before:border-t-2 before:border-b before:border-separate before:inset-0 before:font-inter before:md:break-normal">
            <div className="text-white text-[22.4px] items-center bg-[linear-gradient(135deg,rgb(179,153,255),rgb(139,96,255))] shadow-[rgba(139,96,255,0.55)_0px_14px_30px_0px] box-border caret-transparent grid h-[60px] justify-items-center leading-[35.84px] break-words w-[60px] mb-3.5 mx-auto rounded-[20px] md:break-normal">
              <i className="font-black box-border caret-transparent block leading-[22.4px] break-words font-font_awesome_6_pro md:break-normal before:accent-auto before:caret-transparent before:text-white before:text-[22.4px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[22.4px] before:list-outside before:list-none before:break-words before:pointer-events-auto before:text-center before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro before:md:break-normal"></i>
            </div>
            <h3 className="text-[17.92px] font-bold box-border caret-transparent leading-[28.672px] break-words my-1.5 md:break-normal">
              Safety &amp; Quality
            </h3>
            <p className="text-[15.04px] box-border caret-transparent leading-[24.064px] break-words mb-2.5 md:break-normal">
              Account-first design
            </p>
            <p className="text-[15.2px] box-border caret-transparent leading-[24.32px] break-words md:break-normal">
              Each release is validated for clean performance and detection
              resistance. Our security measures ensure your sessions remain
              private, protected, and reliable.
            </p>
          </article>
          <article className="relative shadow-[rgba(0,0,0,0.55)_0px_18px_38px_0px] box-border caret-transparent break-words text-center border overflow-hidden pt-6 pb-[22px] px-[22px] rounded-[18px] border-solid border-white/10 md:break-normal before:accent-auto before:border-b-violet-500/20 before:border-l-gray-400 before:border-r-gray-400 before:border-t-violet-400/70 before:caret-transparent before:text-gray-400 before:block before:text-[13px] before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-[20.8px] before:list-outside before:list-none before:opacity-55 before:break-words before:pointer-events-none before:absolute before:text-center before:indent-[0px] before:normal-case before:visible before:rounded-[18px] before:border-t-2 before:border-b before:border-separate before:inset-0 before:font-inter before:md:break-normal">
            <div className="text-white text-[22.4px] items-center bg-[linear-gradient(135deg,rgb(179,153,255),rgb(139,96,255))] shadow-[rgba(139,96,255,0.55)_0px_14px_30px_0px] box-border caret-transparent grid h-[60px] justify-items-center leading-[35.84px] break-words w-[60px] mb-3.5 mx-auto rounded-[20px] md:break-normal">
              <i className="font-black box-border caret-transparent block leading-[22.4px] break-words font-font_awesome_6_pro md:break-normal before:accent-auto before:caret-transparent before:text-white before:text-[22.4px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[22.4px] before:list-outside before:list-none before:break-words before:pointer-events-auto before:text-center before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro before:md:break-normal"></i>
            </div>
            <h3 className="text-[17.92px] font-bold box-border caret-transparent leading-[28.672px] break-words my-1.5 md:break-normal">
              Instant Delivery
            </h3>
            <p className="text-[15.04px] box-border caret-transparent leading-[24.064px] break-words mb-2.5 md:break-normal">
              Ready when you are
            </p>
            <p className="text-[15.2px] box-border caret-transparent leading-[24.32px] break-words md:break-normal">
              As soon as your transaction completes, your tools are instantly
              available. Start playing immediately — no waiting, no delays.
            </p>
          </article>
          <article className="relative shadow-[rgba(0,0,0,0.55)_0px_18px_38px_0px] box-border caret-transparent break-words text-center border overflow-hidden pt-6 pb-[22px] px-[22px] rounded-[18px] border-solid border-white/10 md:break-normal before:accent-auto before:border-b-violet-500/20 before:border-l-gray-400 before:border-r-gray-400 before:border-t-violet-400/70 before:caret-transparent before:text-gray-400 before:block before:text-[13px] before:not-italic before:normal-nums before:font-normal before:tracking-[normal] before:leading-[20.8px] before:list-outside before:list-none before:opacity-55 before:break-words before:pointer-events-none before:absolute before:text-center before:indent-[0px] before:normal-case before:visible before:rounded-[18px] before:border-t-2 before:border-b before:border-separate before:inset-0 before:font-inter before:md:break-normal">
            <div className="text-white text-[22.4px] items-center bg-[linear-gradient(135deg,rgb(179,153,255),rgb(139,96,255))] shadow-[rgba(139,96,255,0.55)_0px_14px_30px_0px] box-border caret-transparent grid h-[60px] justify-items-center leading-[35.84px] break-words w-[60px] mb-3.5 mx-auto rounded-[20px] md:break-normal">
              <i className="font-black box-border caret-transparent block leading-[22.4px] break-words font-font_awesome_6_pro md:break-normal before:accent-auto before:caret-transparent before:text-white before:text-[22.4px] before:not-italic before:normal-nums before:font-black before:tracking-[normal] before:leading-[22.4px] before:list-outside before:list-none before:break-words before:pointer-events-auto before:text-center before:indent-[0px] before:normal-case before:visible before:border-separate before:font-font_awesome_6_pro before:md:break-normal"></i>
            </div>
            <h3 className="text-[17.92px] font-bold box-border caret-transparent leading-[28.672px] break-words my-1.5 md:break-normal">
              Secure Payments
            </h3>
            <p className="text-[15.04px] box-border caret-transparent leading-[24.064px] break-words mb-2.5 md:break-normal">
              Peace of mind with every purchase
            </p>
            <p className="text-[15.2px] box-border caret-transparent leading-[24.32px] break-words md:break-normal">
              All payments are handled through a robust and encrypted system,
              ensuring your data and transactions stay protected at every step.
            </p>
          </article>
        </div>
      </div>
    </section>
  );
};
